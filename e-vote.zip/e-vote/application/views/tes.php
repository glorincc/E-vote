<table border="1">
	<thead>
		<tr>
			<th colspan="3">Penerimaan</th>
			<th colspan="3">Potongan</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($potongan as $p){ ?>
		<tr>
			<td><?php echo $p['tipe'] ?> p</td>
			<td>data</td>
			<td>data</td>
		
		<?php } ?>
		<?php foreach ($penerimaan as $pp){ ?>
			<td><?php echo $pp['tipe'] ?> pp</td>
			<td>data</td>
			<td>data</td>
			<tr>
				<td colspan="3"></td>
			</tr>
		<?php } ?>
	</tr>
	</tbody>
</table>			