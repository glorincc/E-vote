<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title><?= $title ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta content="A premium admin dashboard template by mannatthemes" name="description" />
		<meta content="Mannatthemes" name="author" />

		<!-- App favicon -->
		<link rel="shortcut icon" href="<?= base_url(); ?>mods/assets/images/logo-sm2.png">
		<link href="<?= base_url(); ?>mods/assets/plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
		<!--Morris Chart CSS -->
        <link rel="stylesheet" href="<?= base_url(); ?>mods/assets/plugins/morris/morris.css">
		<!-- DataTables -->
        <link href="<?= base_url(); ?>mods/assets/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= base_url(); ?>mods/assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="<?= base_url(); ?>mods/assets/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" /> 
        <link href="<?= base_url(); ?>mods/assets/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
		<!-- App css -->
		<link href="<?= base_url(); ?>mods/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="<?= base_url(); ?>mods/assets/css/icons.css" rel="stylesheet" type="text/css" />
		<link href="<?= base_url(); ?>mods/assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
		<link href="<?= base_url(); ?>mods/assets/css/style.css" rel="stylesheet" type="text/css" />
		<!-- jQuery  -->
		<script src="<?= base_url(); ?>mods/assets/js/jquery.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/bootstrap.bundle.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/metisMenu.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/waves.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/jquery.slimscroll.min.js"></script>

		
		 
		<style type="text/css" media="screen">
			.left-sidenav-menu li.active > a {
				background:#00001a1a ;
				/*color: #5766da;*/
			}
			.page-wrapper-img {
				/*background-image: url(../images/overlay.png);*/
				background-size: cover;
				background-position: center;
				min-height: 250px;
				-webkit-box-shadow: inset 0 0 0 2000px rgb(31 35 60 / 80%);
				box-shadow: inset 0 0 0 2000px rgb(31 35 60 / 55%);
			}
			.card-header{
				border-bottom: 5px solid #adadad;
			}
			.navbar-custom{
				background: white;
				border-bottom: 5px solid #adadad;
			}
			.left-sidenav-menu li > a:hover {
				background: #e5e5e852;
			}
			.bg-primary{
				background: #280b73 !important;
			}
			.sl2{
				width: 100% !important;
			}
			.modal-xx{
/*				max-width: 75%;*/
			}
			#header, #nav, .noprint
			{
				display: none;
			}
			@print {
			    @page :footer {
			        display: none
			    }
			 
			    @page :header {
			        display: none
			    }
			}


			@media print {
			    @page {
			        margin-top: 0;
			        margin-bottom: 0;
			    }
			    body {
			        padding-top: 72px;
			        padding-bottom: 72px ;
			    }
			}
			p{
				font-size: 14px !important;
			}
			body{
/*				background: white;*/
				color: black !important;
			}
		</style>	
		<!-- Sweet-Alert  -->
        <script src="<?= base_url(); ?>mods/assets/plugins/sweet-alert2/sweetalert2.min.js"></script>
        <script src="<?= base_url(); ?>mods/assets/pages/jquery.sweet-alert.init.js"></script>

         <!-- Required datatable js -->
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/jszip.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/pdfmake.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/vfs_fonts.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.html5.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.print.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/responsive.bootstrap4.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/pages/jquery.datatable.init.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/select2/select2.min.js"></script>

        <!--Morris Chart-->
        <script src="<?= base_url() ?>mods/assets/plugins/morris/morris.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/raphael/raphael.min.js"></script>
        <!-- <script src="<?= base_url() ?>mods/assets/pages/jquery.morris.init.js"></script> -->
        
	</head>

	<body style="padding: 10px;" onload="window.print();window.onafterprint = window.close;">
		<center>
			<table style="width: 100%;border-bottom: 5px solid black;" width="100%">
			
			<tbody>
				<tr>
					<td style="width: 20%;">
						<center><img src="<?= base_url(); ?>mods/assets/images/logo-sm.png" width="50%" alt=""></center>
					</td>
					<td>
						<center>
							<h2 style="font-size: 26px;">
								BERITA ACARA HASIL PEMILIHAN<br>
								PIMPINAN ORGANISASI MAHASISWA<br>
								UNIVERSITAS NEGERI MANADO
							</h2>
							<br>
						</center>
					</td>
					<td style="width: 20%;"></td>
				</tr>
			</tbody>
		</table>
		</center>
		
		<br><br><br>
		Pada hari ini  <?= hari($vote->tgl_akhir) ?>, Tanggal <?= tgl_indo(date('Y-m-d',strtotime($vote->tgl_akhir))) ?> telah dilaksanakan Pemilihan pimpinan organisasi mahasiswa <?php echo $vote->nama_grp ?> Lingkup <?php echo $vote->lingkup_vot ?>, dengan hasil : 
		<!-- <table class="" border="0" style="width: 100%;">
			<tbody>
				<tr>
					<td width="" style="">Topik</td>
					<td width="2%">:</td>
					<td><?php echo $vote->nama_vot ?></td>
				</tr>
				<tr>
					<td width="">Lingkup</td>
					<td width="2%">:</td>
					<td><?php echo $vote->lingkup_vot ?></td>
				</tr>
				<tr>
					<?php if ($vote->lingkup_vot == 'Jurusan'){ ?>
						<td width="">Prodi</td>
						<td width="2%">:</td>
						<td><?php echo $vote->nama_jur ?></td>
					<?php }else if($vote->lingkup_vot == 'Fakultas'){ ?>
						<td width="">Fakultas</td>
						<td width="2%">:</td>
						<td><?php echo $vote->nama_fak ?></td>
					<?php } ?>
					
				</tr>
				<tr>
					<td width="">Group</td>
					<td width="2%">:</td>
					<td><?php echo $vote->nama_grp ?></td>
				</tr>
				<tr>
					<td width="15%">Total Kandidat</td>
					<td width="2%">:</td>
					<td><?php echo $vote->Calon ?> Kandidat</td>
				</tr>
				<tr>
					<td width="">Jumlah Pemilih</td>
					<td width="2%">:</td>
					<td><?php echo $vote->Pemilih ?> Orang</td>
				</tr>
				<tr>
					<td width="">Tanggal</td>
					<td width="2%">:</td>
					<td><?php echo date('d/m/Y',strtotime($vote->tgl_awal)) ?> <strong>(s/d)</strong> <?php echo date('d/m/Y',strtotime($vote->tgl_akhir)) ?> </td>
				</tr>
				
			</tbody>
		</table>    -->

		<br><br>

		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Kandidat</th>
					<th><center>Total Vote</center></th>
					<th><center>Bobot(%)</center></th>
					<th><center>Total * Bobot</center></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($res as $re){ ?>
					<tr>
						<td><?php echo $re->Nama ?></td>
						<td><center><?php echo $re->Total_vote ?></center></td>
						<td><center><?php echo round($re->bobot,2) ?></center></td>
						<td><center><?php echo round($re->value,2) ?></center></td>
					</tr>
				<?php } ?>
			</tbody>
		 </table> 
		<br>
		<div class="float-right">
			
		</div>
		<br>
		<center>
			<table width="100%" border="0">
			
				<tbody>
					<tr>
						
						<td colspan="2"><center><b>Tondano</b>, <?php echo tgl_indo(date('Y-m-d')); ?><br><b>Mengetahui,</b></center></td>
					</tr>
					<tr>
						<td colspan="2"><br><br></td>
					</tr>
					<tr>
						<td style="width: 50%;">
							<center>
								<b>Ketua</b>
							</center>
							<br><br><br>
							<center>_______________________</center>
						</td>
						<td style="width: 50%;">
							<center>
								<b>Wakil Ketua</b>
							</center>
							<br><br><br>
							<center>_______________________</center>
						</td>
					</tr>
				</tbody>
			</table>
		</center>
		<br>
		<br>
		<center>
			<table width="100%" border="0">
			
				<tbody>
					<tr>
						
						<td colspan="3"><center><br><b>Saksi - Saksi</b></center></td>
					</tr>
					<tr>
						<td colspan="3"><br><br></td>
					</tr>
					<tr>
						<td>
							<center>
								<b>Saksi 1</b>
							</center>
							<br><br><br>
							<center>_______________________</center>
						</td>
						<td>
							<center>
								<b>Saksi 2</b>
							</center>
							<br><br><br>
							<center>_______________________</center>
						</td>
						<td>
							<center>
								<b>Saksi 3</b>
							</center>
							<br><br><br>
							<center>_______________________</center>
						</td>
					</tr>
				</tbody>
			</table>
		</center>
		<!-- App js -->
		<script src="<?= base_url(); ?>mods/assets/js/app.js"></script>
		<script>
			$(document).ready(function() {
				$('.dtble').DataTable({"language": {"url": "<?php echo base_url() ?>mods/assets/plugins/datatables/id.json"},pagingType: 'numbers'});
				$('body').addClass('enlarge-menu');
				$('.sl2').select2();
			});
		</script>
		<?php echo $this->session->flashdata('call'); ?>
	</body>
</html>