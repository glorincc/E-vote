
<div class="card">
	<div class="card-header bg-primary" style="color: white;">
		<button type="button" class="btn btn-danger float-right" onclick="window.location=''">
			<span aria-hidden="true">&times;</span>
			<span class="sr-only">Close</span>
		</button>
		<?php if ($this->session->userdata('role') == 'admin'){ ?>
			<button type="button" class="btn btn-success float-right" onclick="print()">
				<i class="fa fa-print"></i>
			</button>
		<?php } ?>
		<span style="font-size: 16px;font-style: bold;">Hasil Voting</span>
	</div>
	<div class="card-body" style="overflow: auto;">
		<table class="table">
			<tbody>
				<tr>
					<td width="10%">Topik</td>
					<td width="2%">:</td>
					<td><?php echo $vote->nama_vot ?></td>
				</tr>
				<tr>
					<td width="10%">Lingkup</td>
					<td width="2%">:</td>
					<td><?php echo $vote->lingkup_vot ?></td>
				</tr>
				<tr>
					<?php if ($vote->lingkup_vot == 'Jurusan'){ ?>
						<td width="10%">Prodi</td>
						<td width="2%">:</td>
						<td><?php echo $vote->nama_jur ?></td>
					<?php }else if($vote->lingkup_vot == 'Fakultas'){ ?>
						<td width="10%">Fakultas</td>
						<td width="2%">:</td>
						<td><?php echo $vote->nama_fak ?></td>
					<?php } ?>
					
				</tr>
				<tr>
					<td width="10%">Group</td>
					<td width="2%">:</td>
					<td><?php echo $vote->nama_grp ?></td>
				</tr>
				<tr>
					<td width="15%">Total Kandidat</td>
					<td width="2%">:</td>
					<td><?php echo $vote->Calon ?> Kandidat</td>
				</tr>
				<tr>
					<td width="15%">Jumlah Pemilih</td>
					<td width="2%">:</td>
					<td><?php echo $vote->Pemilih ?> Orang</td>
				</tr>
				<tr>
					<td width="10%">Tanggal</td>
					<td width="2%">:</td>
					<td><?php echo date('d/m/Y H:i',strtotime($vote->tgl_awal)) ?> <strong>(s/d)</strong> <?php echo date('d/m/Y H:i',strtotime($vote->tgl_akhir)) ?></td>
				</tr>
				
			</tbody>
		</table>
		<div class="mb-5" id="chart_res" style="height: 300px"></div>   

		<table class="table">
			<thead>
				<tr>
					<th>Kandidat</th>
					<th><center>Total Vote</center></th>
					<th><center>Bobot(%)</center></th>
					<th><center>Total * Bobot</center></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($res as $re){ ?>
					<tr>
						<td><?php echo $re->Nama ?></td>
						<td><center><?php echo $re->Total_vote ?></center></td>
						<td><center><?php echo round($re->bobot,2) ?></center></td>
						<td><center><?php echo round($re->value,2) ?></center></td>
					</tr>
				<?php } ?>
			</tbody>
		 </table>     
	</div>
</div>

<script type="text/javascript">
Morris.Donut({
  element: 'chart_res',
  data: [
	<?php
		end($res);
		$last_key = key($res);
	 ?>
	<?php foreach ($res as $key => $r ){ ?>
		{label:"<?php echo $r->label ?>",value:<?php echo (int)round($r->value,2) ?>}<?php if ($key !== $last_key) echo ", "; ?>
	<?php } ?>
	],
  //resize: true
});

function print()
{
	
	window.open('<?php echo site_url('Admin/print_hasil_vote/'.encrypt_url($vote->id_vot )) ?>','newwindow-<?php echo md5(date('dmyHis')) ?>','width=926,height=972'); return false;	
}
</script>	