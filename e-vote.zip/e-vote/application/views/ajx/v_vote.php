<div class="row">
	<?php if ($status == false){ ?>
		<div class="col-md-12">
			<div class="alert alert-success border-0" role="alert">
				<strong></strong> Sudah pernah melakukan vote
			</div>
		</div>
	<?php }else{ ?>
		<div class="col-md-12">
			<div class="alert alert-warning border-0" role="alert">
				<strong></strong> Silahkan memilih kandidat
			</div>
		</div>
	<?php } ?>
	<div class="col-md-12">
		<table class="table">
			<tbody>
				<tr>
					<td width="10%">Topik</td>
					<td width="2%">:</td>
					<td><?php echo $vote->nama_vot ?></td>
				</tr>
				<tr>
					<td width="10%">Lingkup</td>
					<td width="2%">:</td>
					<td><?php echo $vote->lingkup_vot ?></td>
				</tr>
				<tr>
					<?php if ($vote->lingkup_vot == 'Jurusan'){ ?>
						<td width="10%">Prodi</td>
						<td width="2%">:</td>
						<td><?php echo $vote->nama_jur ?></td>
					<?php }else if($vote->lingkup_vot == 'Fakultas'){ ?>
						<td width="10%">Fakultas</td>
						<td width="2%">:</td>
						<td><?php echo $vote->nama_fak ?></td>
					<?php } ?>
					
				</tr>
				<tr>
					<td width="10%">Group</td>
					<td width="2%">:</td>
					<td><?php echo $vote->nama_grp ?></td>
				</tr>
				<tr>
					<td width="15%">Total Kandidat</td>
					<td width="2%">:</td>
					<td><?php echo $vote->Calon ?> Kandidat</td>
				</tr>
				<tr>
					<td width="10%">Tanggal</td>
					<td width="2%">:</td>
					<td><?php echo date('d/m/Y H:i',strtotime($vote->tgl_awal)) ?> <strong>(s/d)</strong> <?php echo date('d/m/Y H:i',strtotime($vote->tgl_akhir)) ?> </td>
				</tr>
				
			</tbody>
		</table>
	</div>
	<hr>
	<?php if ($kandidat != null){ ?>
		<?php foreach ($kandidat as $k){ ?>
			<div class="col-md-6">
				<div class="card">
					<div class="card-body">
						<div class="text-center">
							<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" alt="user" class="rounded-circle thumb-xl img-thumbnail mb-1">
							<h3><?php echo $k->Nama ?></h3>
							<p class="mb-0 text-muted" title="">
								<span class="badge badge-pill badge-danger"><?php echo $k->JK ?></span> 
								<span class="badge badge-pill badge-warning"><?php echo $k->nama_fak ?></span>
								<span class="badge badge-pill badge-success"><?php echo $k->nama_jur ?></span>
							</p>
							<br>
							<?php if ($status == true){ ?>
								<button type="button" class="btn btn-sm btn-block btn-primary" onclick="vote('<?php echo encrypt_url($k->id_kandidat) ?>','<?php echo encrypt_url($vote->id_vot) ?>')">Pilih</button>
							<?php }else{ ?>
								<button type="button" disabled="" class="btn btn-block btn-primary" title="Sudah pernah melakukan vote" onclick="swal('warning','Sudah pernah melakukan vote','warning')">Pilih</button>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	<?php } ?>
</div>

<script>
	function vote(arg,arg1)
	{
		window.location = "<?php echo site_url('Mahasiswa/vote_kandidat/') ?>"+arg+"/"+arg1
	}
</script>	