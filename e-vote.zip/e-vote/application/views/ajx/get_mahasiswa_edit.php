<div class="row">
	<div class="col-md-6 form-group">
		<label class="required">NIM</label>
		<input type="hidden" name="idmahasiswa" value="<?php echo encrypt_url($mahasiswa->IdMahasiswa) ?>">
		<input type="number" class="form-control" name="nim" required value="<?php echo $mahasiswa->NIM ?>">
	</div>
	<div class="col-md-6 form-group">
		<label class="required">Nama</label>
		<input type="text" class="form-control" name="nama" required value="<?php echo $mahasiswa->Nama ?>">
	</div>
	<div class="col-md-6 form-group">
		<label class="required">Fakultas</label>
		<select required class="form-control sl2-edit" id="fak_edit" name="fakultas" style="width: 100%;" onchange="get_jur('edit')">
			<option  value="<?php echo encrypt_url($mahasiswa->id_fak) ?>"><?php echo $mahasiswa->nama_fak ?></option>
			<?php foreach ($fak as $f){ ?>
				<option value="<?php echo encrypt_url($f->id_fak) ?>"><?php echo $f->nama_fak ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-6 form-group">
		<label class="required">Jurusan</label>
		<select required class="form-control sl2-edit" id="jur_edit" name="jurusan" style="width: 100%;">
			<option  value="<?php echo encrypt_url($mahasiswa->id_jur) ?>"><?php echo $mahasiswa->nama_jur ?></option>
			<?php foreach ($jur as $j){ ?>
				<option value="<?php echo encrypt_url($j->id_jur) ?>"><?php echo $j->nama_jur ?></option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-4 form-group">
		<label class="required">Jenis Kelamin</label>
		<select name="jk" class="form-control" required>
			<?php if ($mahasiswa->JK == 'Perempuan'){ ?>
				<option value="Perempuan">Perempuan</option>
				<option value="Laki-Laki">Laki-Laki</option>
			<?php }else if($mahasiswa->JK == 'Laki-Laki'){ ?>
				<option value="Laki-Laki">Laki-Laki</option>
				<option value="Perempuan">Perempuan</option>
			<?php } ?>
		</select>
	</div>
	<div class="col-md-4 form-group">
		<label class="required">Tahun Masuk</label>
		<input type="number" name="masuk" class="form-control" required value="<?php echo $mahasiswa->Tahun_Masuk ?>">
	</div>
	<div class="col-md-4 form-group">
		<label class="required">Tgl Lahir</label>
		<input type="date" name="tgl_lahir" class="form-control" required value="<?php echo $mahasiswa->Tgl_Lahir ?>">
	</div>
	<div class="col-md-6 form-group">
		<label class="required">No.HP</label>
		<input type="text" name="nohp" class="form-control" required value="<?php echo $mahasiswa->NoHP ?>">
	</div>
	<div class="col-md-6 form-group">
		<label class="required">Email</label>
		<input type="email" name="email" class="form-control" required value="<?php echo $mahasiswa->Email ?>">
	</div>
</div>

<script>
	$('.sl2-edit').select2();
</script>