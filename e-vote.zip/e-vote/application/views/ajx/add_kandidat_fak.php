<div class="row">
	<!-- <div class="col-md-12">
		<h3><?php echo $vote->nama_vot ?></h3>
		<p>Lingkup : <?php echo $vote->lingkup_vot ?></p>
		<p>Group : <?php echo $vote->nama_grp ?></p>
		<hr>
	</div> -->
	<div class="col-md-4">
		<form action="<?php echo site_url('Fakultas/simpan_kandidat') ?>" method="post" accept-charset="utf-8">
			<div class="form-group">
				<input type="hidden" name="vote" value="<?php echo encrypt_url($vote->id_vot) ?>">
				<label>Kandidat</label>
				<select name="kandidat[]" class="form-control sl2-edit" multiple="" required style="width: 100%;">
					<?php foreach ($mahasiswa as $m){ ?>
						<option value="<?php echo encrypt_url($m->IdMahasiswa) ?>"><?php echo $m->NIM ?> <?php echo $m->Nama ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-primary">Tambah</button>
			</div>
		</form>
	</div>
	<div class="col-md-8">
		<table class="dtble-edit table dt-responsive table-hover nowrap dataTable no-footer dtr-inline table-bordered" style="border-collapse: collapse; border-spacing: 0px; width: 100%;">
			<thead>
				<tr>
					<th width="5%"><center>No.</center></th>
					<th width="50%">Nama</th>
					<th>Jenis Kelamin</th>
					<th width="7%"><center>Aksi</center></th>
				</tr>
			</thead>
			<tbody>
				<?php if ($kandidat != null){ ?>
					<?php $no=1; foreach ($kandidat as $k){ ?>
						<tr>
							<td><center><?php echo $no ?></center></td>
							<td><?php echo $k->Nama ?></td>
							<td><?php echo $k->JK ?></td>
							<td>
								<center>
									<a href="javascript: void(0);" class="" onclick="window.location='<?php echo site_url('Fakultas/hapus_kandidat/'.encrypt_url($k->id_kandidat).'/'.encrypt_url($vote->id_vot)) ?>'"><i class="fas fa-trash-alt text-danger"></i></a>
								</center>
							</td>
						</tr>
					<?php $no++;} ?>
				<?php } ?>
			</tbody>
		</table>

	</div> 
</div>

<script>
	$('.sl2-edit').select2();
	$('.dtble-edit').DataTable({"language": {"url": "<?php echo base_url() ?>mods/assets/plugins/datatables/id.json"}});
</script>