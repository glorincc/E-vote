<div class="row">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header bg-primary">
				<h4 class="header-title mt-2" style="color: white;">TAMBAH Prodi</h4>
			</div>
			<div class="card-body">
				<form action="<?php echo site_url('Admin/simpan_jurusan') ?>" method="post" accept-charset="utf-8">
					<div class="form-group">
						<label class="required">Nama Prodi</label>
						<input type="text" required class="form-control" name="jurusan" placeholder="Nama Prodi">
					</div>
					<div class="form-group">
						<label class="required">Fakultas</label>
						<select name="fakultas" class="form-control sl2" required style="width: 100%;">
							<option value="">--Pilih</option>
							<?php foreach ($fak as $f){ ?>
								<option value="<?php echo encrypt_url($f->id_fak) ?>"><?php echo $f->nama_fak ?></option>
							<?php } ?>
						</select>	
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">Simpan</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-8">
		<div class="card">
			<div class="card-header bg-primary">	
				<div class="row">
					<div class="col-md-6">
						<h4 class="header-title mt-2" style="color: white;">DATA Prodi</h4>
					</div>
					
				</div>
			</div>
			<div class="card-body">
				 <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
					<thead>
						<tr>
							<th width="5%">No</th>
                            <th>Fakultas</th>
                            <th>Nama Prodi</th>
                            <th width="50px">Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php if ($jur){ ?>
							<?php $no = 1; foreach ($jur as $j){ ?>
								<tr>
									<td><center><?php echo $no ?></center></td>
									<td>
										<?php echo $j->nama_fak ?>
									</td>
									<td>
										<?php echo $j->nama_jur ?>
									</td>
									<td>
										<center>
											<a href="javascript: void(0);" class="" data-toggle="modal" data-target="#m<?php echo encrypt_url($j->id_jur) ?>"><i class="fas fa-edit text-success"></i></a>
											<a href="javascript: void(0);" class="" onclick="window.location='<?php echo site_url('Admin/hapus_jurusan/'.encrypt_url($j->id_jur)) ?>'"><i class="fas fa-trash-alt text-danger"></i></a>
										</center>
									</td>
								</tr>
								<div class="modal fade" id="m<?php echo encrypt_url($j->id_jur) ?>">
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content">
											<div class="modal-header bg-primary">
												<h5 class="modal-title mt-0" id="edit_header" style="color: white;">Edit Data Prodi</h5>
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
											</div>
											<form action="<?php echo site_url('Admin/simpan_edit_jurusan') ?>" method="post" accept-charset="utf-8">
												<div class="modal-body" id="edit_body" style="background: white;">
													<div class="form-group">
														<label class="required">Nama Prodi</label>
														<input type="text" required class="form-control" name="jurusan" value="<?php echo $j->nama_jur ?>">
														<input type="hidden" name="jur" value="<?php echo encrypt_url($j->id_jur) ?>">
													</div>
													<div class="form-group">
														<label class="required">Fakultas</label>
														<select name="fakultas" class="form-control sl2" style="width: 100%;">
															<option value="<?php echo encrypt_url($j->id_fak) ?>"><?php echo $j->nama_fak ?></option>
															<?php $fak_edit = $this->db->get_where('tbl_mas_fakultas', 'id_fak != "'.$j->id_fak.'"')->result(); ?>
															<?php foreach ($fak_edit as $fe){ ?>
																<option value="<?php echo encrypt_url($fe->id_fak) ?>"><?php echo $fe->nama_fak ?></option>
															<?php } ?>
														</select>
													</div>
												</div>	
												<div class="modal-footer">
													<button type="submit" class="btn btn-primary">Simpan</button>
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
												</div>
											</form>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div><!-- /.modal -->
							<?php $no++;} ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>		
	</div>
</div>