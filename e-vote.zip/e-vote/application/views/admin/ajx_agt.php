<div class="row">
	<div class="col-md-12">
		<h3><?php echo $grp->nama_grp ?></h3>
		<p><?php echo $grp->keterangan_grp ?></p>
		<hr>
	</div>
	<div class="col-md-4">
		<form action="<?php echo site_url('Admin/tambah_anggota') ?>" method="post" accept-charset="utf-8">
			<div class="form-group">
				<input type="hidden" name="id_grp" value="<?php echo encrypt_url($grp->id_grp) ?>">
				<label>Mahasiswa</label>
				<select name="mahasiswa" class="form-control sl2-edit" style="width: 100%;" required>
					<option value="">--Pilih</option>
					<?php foreach ($mahasiswa as $m){ ?>
						<option value="<?php echo encrypt_url($m->IdMahasiswa) ?>"><?php echo $m->NIM ?> <?php echo $m->Nama ?> | <?php echo $m->nama_fak ?> | <?php echo $m->nama_jur ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-primary">Tambah sebagai anggota</button>
			</div>
		</form>
	</div>
	<div class="col-md-8" style="overflow:auto;">
		<table class="dtble table dt-responsive table-hover nowrap dataTable no-footer dtr-inline" style="border-collapse: collapse; border-spacing: 0px; width: 100%;">
			<thead>
				<tr>
					<th width="5%">No</th>
					<th width="85%">Mahasiswa</th>
					<th width="85%">Fakultas</th>
					<th width="85%">Prodi</th>
					<th width="">Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php if ($anggota != null){ ?>
					<?php $no=1; foreach ($anggota as $agt){ ?>
						<tr>
							<td width="1%"><center><?php echo $no; ?></center></td>
							<td><?php echo $agt->Nama ?></td>
							<td><?php echo $agt->nama_fak ?></td>
							<td><?php echo $agt->nama_jur ?></td>
							<td width="5%">
								<center>
									<a href="javascript: void(0);" class="" onclick="window.location='<?php echo site_url('Admin/hapus_agt/'.encrypt_url($agt->id_agt).'/'.encrypt_url($agt->id_grp)) ?>'"><i class="fas fa-trash-alt text-danger"></i></a>
								</center>
							</td>
						</tr>
					<?php $no++;} ?>
				<?php }?>
			</tbody>
		</table>
	</div>

</div>
<script>
	$('.sl2-edit').select2();
	$('.dtble').DataTable({"language": {"url": "<?php echo base_url() ?>mods/assets/plugins/datatables/id.json"}});
</script>