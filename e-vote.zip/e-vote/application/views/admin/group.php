<div class="row" id="view">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<div class="d-flex align-items-center">
	                <strong>Loading...</strong>
	                <div class="spinner-border ml-auto" role="status" aria-hidden="true"></div>
	            </div>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="m_agt">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<h4 class="modal-title text-white">Anggota</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<div class="modal-body" id="view_agt" style="background: white;">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
	function get_agt(arg)
	{
		$.ajax({
			url: '<?php echo site_url('Admin/get_agt') ?>',
			type: 'POST',
			dataType: 'html',
			data: {arg: arg},
			
			success: function(data, textStatus, xhr) {
				$('#m_agt').modal('show');
				$('#view_agt').html(data);
			},
			error: function(xhr, textStatus, errorThrown) {
				//called when there is an error
				swal('error',errorThrown,'error');
			}
		});
		
	}
</script>
<script>
	$.ajax({
		url: '<?php echo site_url('Admin/ajx_grp') ?>',
		type: 'POST',
		dataType: 'html',
		success: function(data, textStatus, xhr) {
			$('#view').html(data)
		},
		error: function(xhr, textStatus, errorThrown) {
			swal('error',errorThrown,'error');
		}
	});
	
</script>
