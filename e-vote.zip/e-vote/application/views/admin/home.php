<div class="col-12">
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-md-9">
					<h4 class="mt-0">Hello ! <?php echo $this->session->userdata('nama'); ?></h4>  
					<p class="text-muted">Have a nice day.</p>
					<div class="row justify-content-center">
						<div class="col-md-3">
							<div class="card mb-0">
								<div class="card-body">
									<div class="float-right">
										<i class="dripicons-user-group font-24 text-secondary"></i>
									</div> 
									<span class="badge badge-danger">MAHASISWA</span>
									<h3 class="font-weight-bold"><?php echo $c_mahasiswa ?></h3>
									
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="card mb-0">
								<div class="card-body">
									<div class="float-right">
										<i class="mdi mdi-office-building font-20 text-secondary"></i>
									</div> 
									<span class="badge badge-info">FAKULTAS</span>
									<h3 class="font-weight-bold"><?php echo $c_fak ?></h3>
									
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="card mb-0">
								<div class="card-body">
									<div class="float-right">
										<i class="mdi mdi-account-group font-20 text-secondary"></i>
									</div> 
									<span class="badge badge-warning">GROUP</span>
									<h3 class="font-weight-bold"><?php echo $c_grp ?></h3>
									
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="card mb-0">
								<div class="card-body">
									<div class="float-right">
										<i class="mdi mdi-chat-alert font-20 text-secondary"></i>
									</div> 
									<span class="badge badge-success">Vote</span>
									<h3 class="font-weight-bold"><?php echo $c_vote ?></h3>
									
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 align-self-center">
					<img src="<?= base_url() ?>mods/assets/images/dash.svg" alt="" class="img-fluid">
				</div>
			</div>                                                                              
		</div><!--end card-body--> 
		<div class="card-body bg-light">
			<div class="row">
				<div class="col-8">
					<div class="media">
						<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" height="40" class="mr-4" alt="...">
						<div class="media-body align-self-center">                                                                                                                       
							<p class="mb-0 text-muted">There are many variations of passages 
								of Lorem Ipsum available, but the majority 
								have suffered alteration in some form, by injected
									humour, or randomised words.
							</p>
						</div>
					</div>                                               
				</div>
			</div>
		</div><!--end card-body--> 
	</div><!--end card--> 
</div> <!--end col--> 