<div class="col-md-12">
	<div class="card">
		<div class="card-header bg-primary">	
			<div class="row">
				<div class="col-md-6">
					<h4 class="header-title mt-2" style="color: white;">DATA MAHASISWA</h4>
				</div>
				<div class="col-md-6">
					<button type="button" class="btn btn-danger waves-effect waves-light float-right" onclick="$('#modal-add').modal('show')">Tambah Mahasiswa</button>
				</div>
			</div>
		</div><br>
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-3">
					<div class="form-group">
						<label>Pilih Fakultas</label>
						<select class="form-control fakultas" name="">
							<option>-- Pilih --</option>
							<option value="fakultas teknik">Fakultas Teknik</option>
							<option value="fakultas ilmu sosial">Fakultas Ilmu Sosial</option>
							<option value="fakultas matematika dan ilmu pengetahuan alam">Fakultas Matematika Dan Ilmu Pengetahuan Alam</option>
							<option value="fakultas ekonomi">Fakultas Ekonomi</option>
							<option value="fakultas ilmu pendidikan">Fakultas Ilmu Pendidikan</option>
							<option value="fakultas bahasa dan seni">Fakultas Bahasa Dan Seni</option>
							<option value="fakultas ilmu keolahragaan">Fakultas Ilmu Keolahragaan</option>
						</select>
					</div>
				</div>
				<div class="col-lg-3">
					<div class="form-group">
						<label>Pilih Jurusan dan Prodi</label>
						<select class="form-control prodi" name="">
							<option>-- Pilih --</option>
							<option value="ptik">PTIK</option>
							<option value="teknik informatika">Teknik Infornatika</option>
							<option value="teknik sipil">Teknik Sipil</option>
							<option value="teknik mesin">Teknik Mesin</option>
							<option value="teknik arsitektur">Teknik Arsitektur</option>
							<option value="pendidikan kesejahteraan keluargaa">Pendidikan Kesejahtraan Keluarga</option>
							<option value="pendidikan teknik bangunan">Pendidikan Teknik Bangunan</option>
							<option value="pendidikan teknik elektro">Pendidikan Teknik Elektro</option>
							<option value="pendidikan teknik mesin">Pendidikan Teknik Mesin</option>
							<option value="geografi">Geografi</option>
							<option value="ilmu administrasi negara">Ilmu Administrasi Negara</option>
							<option value="ilmu hukum">Ilmu Hukum</option>
							<option value="pendidikan ips">Pendidikan IPS</option>
							<option value="pendidikan sejarah">Pendidikan Sejarah</option>
							<option value="pendidikan geografi">Pendidikan Geografi</option>
							<option value="pendidikan sosiologi">Pendidikan Sosiologi</option>
							<option value="pendidikan pancasila dan kewarganegaraan">PPKN</option>
							<option value="pendidikan fisika">Pendidikan Fisika</option>
							<option value="biologi">Biologi</option>
							<option value="kimia">Kimia</option>
							<option value="pendidikan matematika">Pendidikan Matematika</option>
							<option value="pendidikan biologi">Pendidikan Biologi</option>
							<option value="pendidikan kimia">Pendidikan Kimia</option>
							<option value="pendidikan ipa">Pendidikan IPA</option>
							<option value="manajemen">Manajemen</option>
							<option value="ilmu ekonomi">Ilmu Ekonomi</option>
							<option value="pendidikan ekonomi">Pendidikan Ekonomi</option>
							<option value="pendidikan guru sekolah dasar">PGSD</option>
							<option value="pendidikan guru anak usia dini">Pendidikan Guru Anak Usia Dini</option>
							<option value="psikologi">Psikologi</option>
							<option value="bimbingan konseling">Bimbingan Konseling</option>
							<option value="pendidikan khusus">Pendidikan Khusus</option>
							<option value="pendidikan luar sekolah">Pendidikan Luar Sekolah</option>
							<option value="sastra inggris">Sastra Inggris</option>
							<option value="pendidikan bahasa dan sastra indonesia">Pendidikan Bahasa dan Sastra Indonesia</option>
							<option value="pendidikan bahasa inggris">Pendidikan Bahasa Inggris</option>
							<option value="pendidikan bahasa jepang">Pendidikan Bahasa Jepang</option>
							<option value="pendidikan bahasa prancis">Pendidikan Bahasa Prancis</option>
							<option value="pendidikan bahasa jerman">Pendidikan Bahasa Jerman</option>
							<option value="Pendidikan Seni, Drama, Tari, dan Musik">Pendidikan Seni, Drama, Tari, dan Musik</option>
							<option value="pendidikan seni rupa">Pendidikan Seni Rupa</option>
							<option value="pendidikan jasmani, kesehatan dan rekreasi">Pendidikan Jasmani, Kesehatan dan Rekreasi</option>
							<option value="ilmu keolahragaan">Ilmu Keolahragaan</option>
							<option value="ilmu kesehatan masyarakat">Ilmu Kesehatan Masyarakat</option>
							<option value="Pendidikan kepelatihan olahraga">Pendidikan Kepelatihan Olahraga</option>
							<option value="manajemen pemasaran">Manajemen pemasaran</option>
							<option value="pendidikan guru agama hindu">Pendidikan Guru Agama Hindu</option>
						</select>
					</div>
				</div>
			</div>
		</div>
		<div class="card-body" style="overflow: auto;">
			<table class="dtble_m table dt-responsive table-hover nowrap dataTable no-footer dtr-inline" style="border-collapse: collapse; border-spacing: 0px; width: 100%;">
				<thead>
					<tr>
						<th width="5%"><center>No</center></th>
						<th width="20%">Nama</th>
						<th width="20%">NIM</th>
						<th width="15%">Fakultas</th>
						<th width="15%">Prodi</th>
						<th width="15%">Tahun Masuk</th>
						<th width="10%">Jenis Kelamin</th>
						<th width="10%">Tanggal Lahir</th>
						<th width="10%">HP</th>
						<th width="10%">Email</th>
						<th width="10%"><center>Aksi</center></th>
					</tr>
				</thead>
				<tbody>
					<?php if ($mahasiswa != null){ ?>
						<?php $no = 1; foreach ($mahasiswa as $m){ ?>
							<tr>
								<td><center><?php echo $no ?></center></td>
								<td><?php echo $m->Nama ?></td>
								<td><?php echo $m->NIM ?></td>
								<td><?php echo $m->nama_fak ?></td>
								<td><?php echo $m->nama_jur ?></td>
								<td><?php echo $m->Tahun_Masuk ?></td>
								<td><?php echo $m->JK ?></td>
								<td><?php echo date('d/m/Y',strtotime($m->Tgl_Lahir)) ?></td>
								<td><?php echo $m->NoHP ?></td>
								<td><?php echo $m->Email ?></td>
								<td>
									<center>
										<a href="javascript: void(0);" class="" onclick="view_edit('<?php echo encrypt_url($m->IdMahasiswa) ?>')"><i class="fas fa-edit text-success"></i></a>
										<a href="javascript: void(0);" class="" onclick="window.location='<?php echo site_url('Admin/hapus_mahasiswa/'.encrypt_url($m->IdMahasiswa)) ?>'"><i class="fas fa-trash-alt text-danger"></i></a>
									</center>
								</td>
							</tr>
						<?php $no++;} ?>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<div class="modal fade" id="modal-edit">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<h5 class="modal-title mt-0" id="edit_header" style="color: white;">Edit Data Mahasiswa</h5>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			</div>
			<form action="<?php echo site_url('Admin/simpan_edit_mahasiswa') ?>" method="post" accept-charset="utf-8">
				<div class="modal-body" id="edit_body" style="background: white;">

				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Simpan</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="modal-add">
	<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<h5 class="modal-title mt-0" id="edit_header" style="color: white;">Tambah Data Mahasiswa</h5>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			</div>
			<form action="<?php echo site_url('Admin/simpan_mahasiswa') ?>" method="post" accept-charset="utf-8">
				<div class="modal-body" id="add_body" style="background: white;">
					<div class="row">
						<div class="col-md-6 form-group">
							<label class="required">NIM</label>
							<input type="number" class="form-control" name="nim" required id="nim_new" onchange="set_tahun_masuk($(this).val(),$('#tahun_masuk_new'))">
						</div>
						<div class="col-md-6 form-group">
							<label class="required">Nama</label>
							<input type="text" class="form-control" name="nama" required >
						</div>
						<div class="col-md-6 form-group">
							<label class="required">Fakultas</label>
							<select required class="form-control sl2" id="fak" name="fakultas" style="width: 100%;" onchange="get_jur()">
								<option value="">--Pilih</option>
								<?php foreach ($fak as $f){ ?>
									<option value="<?php echo encrypt_url($f->id_fak) ?>"><?php echo $f->nama_fak ?></option>
								<?php } ?>
							</select>
						</div>
						<div class="col-md-6 form-group">
							<label class="required">Jurusan</label>
							<select required class="form-control sl2" id="jur" name="jurusan" style="width: 100%;">
								<option value="">--Pilih</option>
							</select>
						</div>
						<div class="col-md-4 form-group">
							<label class="required">Jenis Kelamin</label>
							<select name="jk" class="form-control" required>
								<option value="Laki-Laki">Laki-Laki</option>
								<option value="Perempuan">Perempuan</option>
							</select>
						</div>
						<div class="col-md-4 form-group">
							<label class="required">Tahun Masuk</label>
							<input type="number" readonly="" name="masuk" class="form-control" required id="tahun_masuk_new">
						</div>
						<div class="col-md-4 form-group">
							<label class="required">Tgl Lahir</label>
							<input type="date" name="tgl_lahir" class="form-control" required >
						</div>
						<div class="col-md-6 form-group">
							<label>No.HP</label>
							<input type="number" name="nohp" class="form-control">
						</div>
						<div class="col-md-6 form-group">
							<label>Email</label>
							<input type="email" name="email" class="form-control">
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Simpan</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
	$('.dtble_m').DataTable({
		responsive:true,
		"language": {"url": "<?php echo base_url() ?>mods/assets/plugins/datatables/id.json"},
		pagingType: 'numbers'
	});
	function view_edit(arg)
	{
		$.ajax({
			url: '<?php echo site_url('Admin/get_edit_mahasiswa') ?>',
			type: 'POST',
			dataType: 'html',
			data: {arg: arg},
			success: function(data, textStatus, xhr) {
				$('#modal-edit').modal('show');
				$('#edit_body').html(data);
			},
			error: function(xhr, textStatus, errorThrown)
			{
				swal('Server ERROR',`${errorThrown}`,'error');
			}
		});
	}


	function get_jur(arg = '')
	{
		let fak;
		let jur;
		if(arg == '' || arg == undefined)
		{
			fak = $('#fak').val();
			jur = $('#jur');
		}
		else if(arg == 'edit')
		{
			fak = $('#fak_edit').val();
			jur = $('#jur_edit');
		}
		jur.html('<option value="">Loading...</option>');
		$.ajax({
			url: '<?php echo site_url('Admin/get_jur') ?>',
			type: 'POST',
			dataType: 'json',
			data: {fak: fak},
			success: function(data, textStatus, xhr) {
				let html = '';
				html +='<option value="">--Pilih</option>';
				for(i=0; i<data.length; i++){
					html += `<option value="${data[i]['id_jur']}">${data[i]['nama_jur']}</option>`;
				}
				jur.html(html);
			},
			error: function(xhr, textStatus, errorThrown)
			{
				swal('Server ERROR',`${errorThrown}`,'error');
			}
		});

	}

	function set_tahun_masuk(arg,element)
	{
		let tahun_masuk = $(element)
		if(arg != '')
		{
			console.log(`20${arg.substring(0,2)}`)
			tahun_masuk.val(`20${arg.substring(0,2)}`);
		}
		else
		{
			tahun_masuk.val('');
		}
	}
</script>
<script type="text/javascript">
	$(document).ready(function() {
	    $('.dtble_m').DataTable();
	    function filterData () {
		    $('.dtble_m').DataTable().search(
		        $('.fakultas').val()
		    	).draw();
		}
		$('.fakultas').on('change', function () {
	        filterData();
	    });
	});
</script>
<script type="text/javascript">
	$(document).ready(function() {
	    $('.dtble_m').DataTable();
	    function filterData () {
		    $('.dtble_m').DataTable().search(
		        $('.prodi').val()
		    	).draw();
		}
		$('.prodi').on('change', function () {
	        filterData();
	    });
	});
</script>