<?php if ($group != null){ ?>
	<?php foreach ($group as $grp){ ?>
		<div class="col-lg-4">
			<div class="card overflow-hidden">
				<div class="card-body bg-gradient<?= rand(1,3) ?>">
					<div class="">
						<div class="card-icon">
							<i class="far fa-user"></i>
						</div>
						<?php $c_grp = $this->db->select('COUNT(IdMahasiswa) AS Total')->get_where('tbl_agt_grp','id_grp = "'.$grp->id_grp.'"')->row()->Total; ?>
						<h2 class="font-weight-bold text-white"><?php echo $c_grp ?></h2>
						<p class="text-white mb-0 font-16">Anggota</p>                                            
					</div>
				</div>
				<div class="card-body dash-info-carousel">                                        
					<div class="text-center">
						<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" alt="user" class="rounded-circle thumb-xl img-thumbnail mb-1">
						<h3><?php echo $grp->nama_grp ?></h3>
						<p class="mb-0 text-muted" title="<?php echo $grp->keterangan_grp ?>"><?php echo limitText($grp->keterangan_grp) ?></p>
						<div class="mt-2 align-item-center">
							<a class="btn btn-sm btn-primary text-light mb-2" href="javascript:void(0);" onclick="get_agt('<?php echo encrypt_url($grp->id_grp) ?>')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Tambah Anggota</a>
							<a class="btn btn-sm btn-warning text-light mb-2" href="javascript:void(0);" data-toggle="modal" data-target="#m<?php echo encrypt_url($grp->id_grp) ?>"><i class="fas fa-edit"></i></a>
							<a class="btn btn-sm btn-danger text-light mb-2" href="javascript:void(0);" onclick="window.location='<?php echo site_url('Admin/hapus_grp/'.encrypt_url($grp->id_grp)) ?>'"><i class="fas fa-trash"></i></a>
						</div>
					</div>
				</div><!--end card-body-->
			</div><!--end card-->
		</div>
		<div class="modal fade" id="m<?php echo encrypt_url($grp->id_grp) ?>">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header bg-primary">
						<h4 class="modal-title text-white">Edit Group - <?php echo $grp->nama_grp ?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							<span class="sr-only">Close</span>
						</button>
					</div>
					<form action="<?php echo site_url('Admin/simpan_edit_group') ?>" method="POST" accept-charset="utf-8">
						<div class="modal-body" style="background: white;">
							<input type="hidden" name="grp" value="<?php echo encrypt_url($grp->id_grp) ?>">
							<div class="form-group">
								<label class="required">Nama Group</label>
								<input type="text" class="form-control" required name="nama_grp" value="<?php echo $grp->nama_grp ?>">
							</div>
							<div class="form-group">
								<label class="required">Keterangan Group</label>
								<textarea name="keterangan_grp" required style="resize: none;height: 200px;" class="form-control"><?php echo $grp->keterangan_grp ?></textarea>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary">Save changes</button>
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->
	<?php } ?>
	<div class="col-md-12">
		<div class="alert alert-outline-purple b-round" role="alert">
            <strong><a href="javascript: void(0);" data-toggle="modal" data-target="#m_add" title="">Klik Disini</a></strong> untuk menambahkan group baru.
        </div>
	</div>
<?php }else{ ?>
	<div class="col-md-12">
		<div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-5 p-0 align-self-center">
                        <img src="<?= base_url() ?>mods/assets/images/error.svg" alt="" class="img-fluid">
                    </div>
                    <div class="col-md-7">
                        <div class="error-content text-center">
                            <h3 class="">🙌</h3>
                            <h4 class="text-primary">Data Group Tidak ditemukan</h4><br>
                            <a class="btn btn-primary mb-5 waves-effect waves-light" href="javascript: void(0);"  data-toggle="modal" data-target="#m_add">Tambah Group</a>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end card-body-->
        </div>
	</div>
<?php } ?>
<div class="modal fade" id="m_add">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<h4 class="modal-title text-white">Tambah Group Baru</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<form action="<?php echo site_url('Admin/simpan_group') ?>" method="POST" accept-charset="utf-8">
				<div class="modal-body" style="background: white;">
					<div class="form-group">
						<label class="required">Nama Group</label>
						<input type="text" class="form-control" required name="nama_grp" value="">
					</div>
					<div class="form-group">
						<label class="required">Keterangan Group</label>
						<textarea name="keterangan_grp" required style="resize: none;height: 200px;" class="form-control"></textarea>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Save changes</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

