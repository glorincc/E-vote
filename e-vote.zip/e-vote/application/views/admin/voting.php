<div class="row">
	<div class="col-md-12" id="div_table">
		<div class="card">
			<div class="card-header bg-primary">	
				<div class="row">
					<div class="col-md-6">
						<h4 class="header-title mt-2" style="color: white;">DATA VOTING</h4>
					</div>
					<div class="col-md-6">
						<button type="button" class="btn btn-danger waves-effect waves-light float-right" onclick="$('#m-add').modal('show')">Tambah Voting	</button>
					</div>
				</div>
			</div>
			<div class="card-body">
				<table class="dtble table dt-responsive table-hover nowrap dataTable no-footer dtr-inline" style="border-collapse: collapse; border-spacing: 0px; width: 100%;">
					<thead>
						<tr>
							<th width="5%"><center>No.</center></th>
							<th width="30%">Topik</th>
							<th>Lingkup</th>
							<th>Fakultas / Prodi</th>
							<th>Group</th>
							<th width="7%"><center>Calon</center></th>
							<th width="7%"><center>Tanggal</center></th>
							<th width="7%"><center>Aksi</center></th>
						</tr>
					</thead>
					<tbody>
						<?php if ($voting != null){ ?>
							<?php $no = 1; foreach ($voting as $v){ ?>
								<tr>
									<td>
										<center>
											<?php echo $no++ ?>
										</center>
									</td>
									<td><?php echo $v->nama_vot ?></td>
									<td><?php echo $v->lingkup_vot ?></td>
									<td>
										<?php if ($v->idp_fak != 0){ ?>
											(Fakultas) <?php echo $v->nama_fak ?>
										<?php }else if($v->idp_jur != 0){ ?>
											(Prodi) <?php echo $v->nama_jur ?>
										<?php }else{ ?>
											-
										<?php } ?>
									</td>
									<td><?php echo $v->nama_grp ?></td>
									<td>
										<center>
											<?php if ($v->idp_fak != 0){ ?>
											<button type="button" class="btn btn-outline-success btn-square waves-effect waves-light" onclick="calon('<?php echo encrypt_url($v->id_vot) ?>','<?php echo encrypt_url($v->idp_fak) ?>','fak')"><?php echo $v->Calon ?> Calon</button>
												
											<?php }else if($v->idp_jur != 0){ ?>
												<button type="button" class="btn btn-outline-success btn-square waves-effect waves-light" onclick="calon('<?php echo encrypt_url($v->id_vot) ?>','<?php echo encrypt_url($v->idp_jur) ?>','jur')"><?php echo $v->Calon ?> Calon</button>
											<?php }else{ ?>
												<button type="button" class="btn btn-outline-success btn-square waves-effect waves-light" onclick="calon('<?php echo encrypt_url($v->id_vot) ?>','0','0')"><?php echo $v->Calon ?> Calon</button>
											<?php } ?>
										</center>
									</td>
									<td>
										<center>
											<?php echo date('d/m/Y H:i',strtotime($v->tgl_awal)) ?> - <?php echo date('d/m/Y H:i',strtotime($v->tgl_akhir)) ?>
										</center>
									</td>
									<td>
										<center>
											<a href="javascript:void(0)" class="" onclick="get_hasil_vote('<?php echo encrypt_url($v->id_vot) ?>')" alt="Hasil Vote" title="Hasil Vote"><i class="fas fa-eye text-warning ml-2"></i></a>
											<a href="javascript:void(0)" class="" onclick="$('#m_edit_vote_<?= encrypt_url($v->id_vot) ?>').modal('show')"><i class="fas fa-edit text-success ml-2"></i></a>
											<a href="javascript:void(0)" class="" onclick="window.location='<?php echo site_url('Admin/hapus_vote/'.encrypt_url($v->id_vot)) ?>'"><i class="fas fa-trash-alt text-danger ml-2"></i></a>
										</center>
									</td>
								</tr>
								<div class="modal fade" id="m_edit_vote_<?= encrypt_url($v->id_vot) ?>">
									<div class="modal-dialog modal-lg " role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h4 class="modal-title">Edit Voting</h4>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
													<span class="sr-only">Close</span>
												</button>
											</div>
											<form id="frm_edit" action="<?php echo site_url('Admin/simpan_edit_vote') ?>" method="post" accept-charset="utf-8">
												<div class="modal-body" style="background: white;">
													<div class="row">
														<input type="hidden" name="vote" value="<?php echo encrypt_url($v->id_vot) ?>">
														<div class="form-group col-md-6">
															<label class="required">Topik</label>
															<input type="text" class="form-control" name="topik" value="<?php echo $v->nama_vot ?>" required>
														</div>
														<div class="form-group col-md-3">
															<label class="required">Tgl Awal</label>
															<input type="datetime-local" class="form-control" id="awal_<?= encrypt_url($v->id_vot) ?>" name="tawal" value="<?php echo $v->tgl_awal ?>" required>
														</div>
														<div class="form-group col-md-3">
															<label class="required">Tgl Akhir</label>
															<input type="datetime-local" class="form-control" id="akhir_<?= encrypt_url($v->id_vot) ?>" name="takhir" value="<?php echo $v->tgl_akhir ?>" required>
														</div>
														<div class="form-group col-md-6 sls">
															<label class="required">Group</label>
															<select name="grp" required class="form-control sl2"style="width: 100%;">
																<option value="<?php echo encrypt_url($v->idp_grp) ?>"><?php echo $v->nama_grp ?></option>
																<?php foreach ($group as $g){ ?>
																	<option value="<?php echo encrypt_url($g->id_grp) ?>"><?php echo $g->nama_grp ?></option>
																<?php } ?>
															</select>
														</div>
														<div class="form-group col-md-6 sls">
															<label class="required">Lingkup</label>
															<select name="lingkup" required class="form-control sl2"style="width: 100%;" onchange="get_jur_edit($(this).val(),'<?= $v->id_vot ?>')">
																<option value="<?php echo $v->lingkup_vot ?>"><?php echo $v->lingkup_vot ?></option>
																<option value="Universitas">Universitas</option>
																<option value="Fakultas">Fakultas</option>
																<option value="Jurusan">Jurusan</option>
																<option value="Organisasi">Organisasi</option>
															</select>
														</div>
														<?php if ($v->lingkup_vot == 'Jurusan'){ ?>
															<script>
																$('.sls').removeClass('col-md-6');
																$('.sls').addClass('col-md-4');
															</script>
															<div class="col-md-4" id="sl_jurusan_edit_<?= $v->id_vot ?>">
																<div class="form-group">
																	<label class="required">Jurusan</label>
																	<select name="jur" class="form-control sl2" required="" style="width: 100%;">
																		<option value="<?= $v->idp_jur ?>"><?php echo $v->nama_jur ?></option>
																		<?php foreach ($jurusan as $jr){ ?>
																			<option value="<?= encrypt_url($jr->id_jur); ?>"><?= $jr->nama_jur ?></option>
																		<?php } ?>
																	</select>
																</div>
															</div>
														<?php }else if($v->lingkup_vot == 'Fakultas'){ ?>
															<script>
																$('.sls').removeClass('col-md-6');
																$('.sls').addClass('col-md-4');
															</script>
															<div class="col-md-4" id="sl_jurusan_edit_<?= $v->id_vot ?>">
																<div class="form-group">
																	<label class="required">Fakultas</label>
																	<select name="fak" class="form-control sl2" required="" style="width: 100%;">
																		<option value="<?= $v->idp_fak ?>"><?php echo $v->nama_fak ?></option>
																		<?php foreach ($fakultas as $fk){ ?>
																			<option value="<?= encrypt_url($fk->id_fak); ?>"><?= $fk->nama_fak ?></option>
																		<?php } ?>
																	</select>
																</div>
															</div>
														<?php }else{ ?>
															<div class="col-md-4" style="display: none;" id="sl_jurusan_edit_<?= $v->id_vot ?>"></div>
														<?php } ?>
														
														<div class="form-group col-md-12">
															<label class="required">Keterangan</label>
															<textarea name="keterangan" class="form-control" required style="resize: none;height: 250px;"><?php echo $v->keterangan_grp ?></textarea>
														</div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
													<button type="submit" class="btn btn-primary" id="btn_edit">Save changes</button>
												</div>
											</form>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div><!-- /.modal -->
							<?php } ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="col-lg-4" id="div_ch">
		
	</div>
</div>
<div class="modal fade" id="m-add">
	<div class="modal-dialog modal-lg " role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Tambah Voting</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<form action="<?php echo site_url('Admin/simpan_vote') ?>" method="post" accept-charset="utf-8">
				<div class="modal-body" style="background: white;">
					<div class="row">
						<div class="form-group col-md-6">
							<label class="required">Topik</label>
							<input type="text" class="form-control" name="topik" required>
						</div>
						<div class="form-group col-md-3">
							<label class="required">Tgl Awal</label>
							<input type="datetime-local" class="form-control" name="tawal" required>
						</div>
						<div class="form-group col-md-3">
							<label class="required">Tgl Akhir</label>
							<input type="datetime-local" class="form-control" name="takhir" required>
						</div>
						
						<div class="form-group col-md-6 sls">
							<label class="required">Group</label>
							<select name="grp" required class="form-control sl2"style="width: 100%;">
								<option value="">--Pilih</option>
								<?php foreach ($group as $g){ ?>
									<option value="<?php echo encrypt_url($g->id_grp) ?>"><?php echo $g->nama_grp ?></option>
								<?php } ?>
							</select>
						</div>
						
						<div class="form-group col-md-6  sls">
							<label class="required">Lingkup</label>
							<select name="lingkup" id="lingkup" onchange="get_jur($(this).val())" required class="form-control sl2"style="width: 100%;">
								<option value="">--Pilih</option>
								<option value="Universitas">Universitas</option>
								<option value="Fakultas">Fakultas</option>
								<option value="Jurusan">Jurusan</option>
								<option value="Organisasi">Organisasi</option>
							</select>
						</div>
						<div class="col-md-4" style="display: none;" id="sl_jurusan">
							
						</div>
						<div class="form-group col-md-12">
							<label class="required">Keterangan</label>
							<textarea name="keterangan" class="form-control" required style="resize: none;height: 250px;"></textarea>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary">Save changes</button>
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="m_add_calon">
	<div class="modal-dialog modal-lg " role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Tambah Kandidat</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<div class="modal-body" id="calon-body" style="padding: 20px;background: white;">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<!-- <button type="submit" class="btn btn-primary">Save changes</button> -->
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<script>
	function calon(arg,arg1,arg2)
	{
		$('#m_add_calon').modal('show');
		$.ajax({
			url: '<?php echo site_url('Admin/get_calon') ?>',
			type: 'POST',
			dataType: 'html',
			data: {arg: arg,arg1:arg1,arg2:arg2},
			success: function(data, textStatus, xhr)
			{
				$('#calon-body').html(data);
			},
			error: function(xhr, textStatus, errorThrown)
			{
				swal('error',errorThrown,'error');
			}
		});
		
	}

	function get_jur(arg)
	{
		if (arg == 'jurusan' || arg == 'Jurusan'){
			$('#sl_jurusan').show();
			$('#sl_jurusan').html(`
				<div class="form-group">
						<label class="required">Jurusan</label>
						<select name="jur" class="form-control sl2" required="">
							<option value="">--Pilih</option>
							<?php foreach ($jurusan as $jr){ ?>
								<option value="<?= encrypt_url($jr->id_jur); ?>"><?= $jr->nama_jur ?></option>
							<?php } ?>
						</select>
					</div>
				`);

			$('.sls').removeClass('col-md-6');
			$('.sls').addClass('col-md-4');
		}else if(arg == 'Fakultas' || arg == 'fakultas'){
			$('#sl_jurusan').html('');
			$('#sl_jurusan').show();
			$('#sl_jurusan').html(`
				<div class="form-group">
						<label class="required">Fakultas</label>
						<select name="fak" class="form-control sl2" required="">
							<option value="">--Pilih</option>
							<?php foreach ($fakultas as $fk){ ?>
								<option value="<?= encrypt_url($fk->id_fak); ?>"><?= $fk->nama_fak ?></option>
							<?php } ?>
						</select>
					</div>
				`);
			$('.sls').removeClass('col-md-6');
			$('.sls').addClass('col-md-4');
		}else{
			$('#sl_jurusan').hide();
			$('#sl_jurusan').html('');
			$('.sls').removeClass('col-md-4');
			$('.sls').addClass('col-md-6');
		}
	}

	function get_jur_edit(arg,id)
	{
		if (arg == 'jurusan' || arg == 'Jurusan'){
			$('#sl_jurusan_edit_'+id).show();
			$('#sl_jurusan_edit_'+id).html(`
				<div class="form-group">
						<label class="required">Jurusan</label>
						<select name="jur" class="form-control sl2" required="">
							<option value="">--Pilih</option>
							<?php foreach ($jurusan as $jr){ ?>
								<option value="<?= encrypt_url($jr->id_jur); ?>"><?= $jr->nama_jur ?></option>
							<?php } ?>
						</select>
					</div>
				`);

			$('.sls').removeClass('col-md-6');
			$('.sls').addClass('col-md-4');
		}else if(arg == 'Fakultas' || arg == 'fakultas'){
			$('#sl_jurusan_edit_'+id).html('');
			$('#sl_jurusan_edit_'+id).show();
			$('#sl_jurusan_edit_'+id).html(`
				<div class="form-group">
						<label class="required">Fakultas</label>
						<select name="fak" class="form-control sl2" required="">
							<option value="">--Pilih</option>
							<?php foreach ($fakultas as $fk){ ?>
								<option value="<?= encrypt_url($fk->id_fak); ?>"><?= $fk->nama_fak ?></option>
							<?php } ?>
						</select>
					</div>
				`);
			$('.sls').removeClass('col-md-6');
			$('.sls').addClass('col-md-4');
		}else{
			$('#sl_jurusan_edit_'+id).hide();
			$('#sl_jurusan_edit_'+id).html('');
			$('.sls').removeClass('col-md-4');
			$('.sls').addClass('col-md-6');
		}
	}


	function get_hasil_vote(arg)
	{
		$('#m_hasil').modal('show');
		$('#div_table').removeClass('col-md-12');
		$('#div_table').addClass('col-lg-8');
		$('#div_ch').addClass('col-lg-4');
		$.ajax({
			url: '<?php echo site_url('Admin/get_hasil') ?>',
			type: 'POST',
			dataType: 'html',
			data: {arg: arg},
			success: function(data, textStatus, xhr)
			{
				$('#div_ch').html(data);
			},
			error: function(xhr, textStatus, errorThrown)
			{
				swal('error',errorThrown,'error');
			}
		});
	}
	
</script>