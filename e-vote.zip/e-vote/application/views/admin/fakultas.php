<div class="row">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header bg-primary">
				<h4 class="header-title mt-2" style="color: white;">TAMBAH FAKULTAS</h4>
			</div>
			<div class="card-body">
				<form action="<?php echo site_url('Admin/simpan_fakultas') ?>" method="post" accept-charset="utf-8">
					<div class="form-group">
						<label class="required">Nama Fakultas</label>
						<input type="text" required class="form-control" name="fakultas" placeholder="nama fakultas">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">Simpan</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="col-md-8">
		<div class="card">
			<div class="card-header bg-primary">	
				<div class="row">
					<div class="col-md-6">
						<h4 class="header-title mt-2" style="color: white;">DATA FAKULTAS</h4>
					</div>
					
				</div>
			</div>
			<div class="card-body">
				 <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
					<thead>
						<tr>
							<th width="5%">No</th>
							<th>Nama Fakultas</th>
							<th width="50px">Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php if ($fak != null){ ?>
							<?php $no=1; foreach ($fak as $f){ ?>
								<tr>
									<td><center><?php echo $no ?></center></td>
									<td><?php echo $f->nama_fak ?></td>
									<td>
										<center>
											<a href="javascript: void(0);" class="" data-toggle="modal" data-target="#m<?php echo encrypt_url($f->id_fak) ?>"><i class="fas fa-edit text-success"></i></a>
											<a href="javascript: void(0);" class="" onclick="window.location='<?php echo site_url('Admin/hapus_fakultas/'.encrypt_url($f->id_fak)) ?>'"><i class="fas fa-trash-alt text-danger"></i></a>
										</center>
									</td>
								</tr>
								<div class="modal fade" id="m<?php echo encrypt_url($f->id_fak) ?>">
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content">
											<div class="modal-header bg-primary">
												<h5 class="modal-title mt-0" id="edit_header" style="color: white;">Edit Data Fakultas</h5>
												<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
											</div>
											<form action="<?php echo site_url('Admin/simpan_edit_fakultas') ?>" method="post" accept-charset="utf-8">
												<div class="modal-body" id="edit_body" style="background: white;">
													<div class="form-group">
														<label class="required">Nama Fakultas</label>
														<input type="text" required class="form-control" name="fakultas" placeholder="nama fakultas" value="<?php echo $f->nama_fak ?>">
														<input type="hidden" name="fak" value="<?php echo encrypt_url($f->id_fak) ?>">
													</div>
												</div>	
												<div class="modal-footer">
													<button type="submit" class="btn btn-primary">Simpan</button>
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
												</div>
											</form>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div><!-- /.modal -->
							<?php $no++;} ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>		
	</div>
</div>