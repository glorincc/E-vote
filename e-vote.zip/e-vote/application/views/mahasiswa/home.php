<div class="col-12">
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-md-9">
					<h4 class="mt-0">Hello ! <?php echo $this->session->userdata('nama'); ?></h4>  
					<p class="text-muted">Have a nice day.</p>
					<div class="row justify-content-center">
						<div class="col-md-8">
							<table class="table">
								<tbody>
									<tr>
										<td width="10%">Nama</td>
										<td width="2%">:</td>
										<td><?php echo $this->session->userdata('nama'); ?></td>
									</tr>
									<tr>
										<td width="10%">NIM</td>
										<td width="2%">:</td>
										<td><?php echo $this->session->userdata('NIM'); ?></td>
									</tr>
									<tr>
										<td width="10%">Fakultas</td>
										<td width="2%">:</td>
										<td><?php echo $this->db->get_where('tbl_mas_fakultas','id_fak = "'.$this->session->userdata('id_fak').'"')->row()->nama_fak; ?></td>
									</tr>
									<tr>
										<td width="10%">Prodi</td>
										<td width="2%">:</td>
										<td><?php echo $this->db->get_where('tbl_mas_jurusan','id_jur = "'.$this->session->userdata('id_jur').'"')->row()->nama_jur; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="col-md-4">
							<div class="col-md-12 mb-2">
								<div class="card mb-0">
									<div class="card-body">
										<div class="float-right">
											<i class="mdi mdi-chat-alert font-20 text-secondary"></i>
										</div> 
										<span class="badge badge-success">Vote By Fakultas</span>
										<h3 class="font-weight-bold"><?php echo $t_vote_fak ?></h3>
									</div>
								</div>
							</div>
							<div class="col-md-12 mb-2">
								<div class="card mb-0">
									<div class="card-body">
										<div class="float-right">
											<i class="mdi mdi-chat-alert font-20 text-secondary"></i>
										</div> 
										<span class="badge badge-warning">Vote By Prodi</span>
										<h3 class="font-weight-bold"><?php echo $t_vote_jur ?></h3>
									</div>
								</div>
							</div>
							<div class="col-md-12 mb-2">
								<div class="card mb-0">
									<div class="card-body">
										<div class="float-right">
											<i class="mdi mdi-chat-alert font-20 text-secondary"></i>
										</div> 
										<span class="badge badge-primary">Vote by Group</span>
										<h3 class="font-weight-bold"><?php echo $t_vote_grp ?></h3>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 align-self-center">
					<img src="<?= base_url() ?>mods/assets/images/dash.svg" alt="" class="img-fluid">
				</div>
			</div>                                                                              
		</div><!--end card-body--> 
		<div class="card-body bg-light">
			<div class="row">
				<div class="col-8">
					<div class="media">
						<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" height="40" class="mr-4" alt="...">
						<div class="media-body align-self-center">                                                                                                                       
							<p class="mb-0 text-muted">There are many variations of passages 
								of Lorem Ipsum available, but the majority 
								have suffered alteration in some form, by injected
									humour, or randomised words.
							</p>
						</div>
					</div>                                               
				</div>
			</div>
		</div><!--end card-body--> 
	</div><!--end card--> 
</div> <!--end col--> 