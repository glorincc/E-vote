<style type="text/css" media="screen">
	.fancybox__content{
		width: 50%;
	}
</style>
<div class="row">
<?php if ($grp != null){ ?>
	<?php foreach ($grp as $g){ ?>
		<?php $vote = $this->db->get_where('tbv_vote', 'idp_grp = "'.$g->id_grp.'"  AND (idp_fak = 0 AND idp_jur = 0)')->result(); ?>
		<?php if ($vote != null){ ?>
			<?php foreach ($vote as $v){ ?>
				<div class="col-lg-6">
					<div class="card overflow-hidden">
						<div class="card-body bg-gradient<?= rand(1,3) ?>">
							<div class="">
								<div class="card-icon">
									<i class="far fa-user"></i>
								</div>
								<h2 class="font-weight-bold text-white"><?php echo $v->nama_vot ?></h2>
								<p class="text-white mb-0 font-16"><span class="badge badge-pill badge-danger"><?php echo $v->lingkup_vot ?></span> - <span class="badge badge-pill badge-info"><?php echo $g->nama_grp ?></span></p>                                            
							</div>
						</div>
						<div class="card-body dash-info-carousel">                                        
							<div class="text-center">
								<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" alt="user" class="rounded-circle thumb-xl img-thumbnail mb-1">
								<h3><?php echo $v->Calon ?> Kandidat</h3>
								<p class="mb-0 text-muted" title=""><span class="badge badge-pill badge-danger"><?php echo date('d/m/Y H:i',strtotime($v->tgl_awal)) ?></span> - <span class="badge badge-pill badge-success"><?php echo date('d/m/Y H:i',strtotime($v->tgl_akhir)) ?></span></p>
								<p class="mt-2"><?php echo limitText($v->keterangan_vot) ?></p>
								<div class="mt-4 align-item-center">
									<?php if ($v->SisaHariAwal > 0){ ?>
										<a class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2" readonly="" href="javascript:void(0);" onclick="swal('warning','Tidak Bisa Melakukan Vote. Karena Belum Sesuai Tanggal','warning')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</a>
									<?php }else if($v->SisaHariAwal <= 0 AND $v->SisaHariAkhir >= 0){ ?>
										<div class="row">
											<a class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2 col-md-6" href="javascript:void(0);" onclick="get_vote('<?php echo encrypt_url($v->id_vot) ?>')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</a>
											
											<a class="btn btn-sm btn-success text-light btn-block mb-2 mt-2 col-md-6" data-fancybox data-type="ajax" href="<?php echo site_url('Mahasiswa/get_hasil/'.encrypt_url($v->id_vot)) ?>"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Lihat Hasil Sementara</a>
										</div>
									<?php }else if($v->Calon < 1){ ?>
										<button type="button" class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2" onclick="swal('warning','Belum Ada Kandidat','warning')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</button>
									<?php }else{ ?>
										<a class="btn btn-sm btn-success text-light btn-block mb-2 mt-2 col-md-6" data-fancybox data-type="ajax" href="<?php echo site_url('Mahasiswa/get_hasil/'.encrypt_url($v->id_vot)) ?>"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Lihat Hasil</a>
									<?php } ?>
								</div>
							</div>
						</div><!--end card-body-->
					</div><!--end card-->
				</div>
			<?php } ?>
		<?php } ?>
		<?php $vote = $this->db->get_where('tbv_vote', 'idp_grp = "'.$g->id_grp.'"  AND (idp_fak = "'.$g->id_fak.'")')->result(); ?>
		<?php if ($vote != null){ ?>
			<?php foreach ($vote as $v){ ?>
				<div class="col-lg-6">
					<div class="card overflow-hidden">
						<div class="card-body bg-gradient<?= rand(1,3) ?>">
							<div class="">
								<div class="card-icon">
									<i class="far fa-user"></i>
								</div>
								<h2 class="font-weight-bold text-white"><?php echo $v->nama_vot ?></h2>
								<p class="text-white mb-0 font-16"><span class="badge badge-pill badge-danger"><?php echo $v->lingkup_vot ?></span> - <span class="badge badge-pill badge-info"><?php echo $g->nama_grp ?></span></p>                                            
							</div>
						</div>
						<div class="card-body dash-info-carousel">                                        
							<div class="text-center">
								<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" alt="user" class="rounded-circle thumb-xl img-thumbnail mb-1">
								<h3><?php echo $v->Calon ?> Kandidat</h3>
								<p class="mb-0 text-muted" title=""><span class="badge badge-pill badge-danger"><?php echo date('d/m/Y H:i',strtotime($v->tgl_awal)) ?></span> - <span class="badge badge-pill badge-success"><?php echo date('d/m/Y H:i',strtotime($v->tgl_akhir)) ?></span></p>
								<p class="mt-2"><?php echo limitText($v->keterangan_vot) ?></p>
								<div class="mt-4 align-item-center">
									<?php if ($v->SisaHariAwal > 0){ ?>
										<a class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2" readonly="" href="javascript:void(0);" onclick="swal('warning','Tidak Bisa Melakukan Vote. Karena Belum Sesuai Tanggal','warning')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</a>
									<?php }else if($v->SisaHariAwal <= 0 AND $v->SisaHariAkhir >= 0){ ?>
										<div class="row">
											<a class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2 col-md-6" href="javascript:void(0);" onclick="get_vote('<?php echo encrypt_url($v->id_vot) ?>')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</a>
											
											<a  class="btn btn-sm btn-success text-light btn-block mb-2 mt-2 col-md-6" data-fancybox data-type="ajax" href="<?php echo site_url('Mahasiswa/get_hasil/'.encrypt_url($v->id_vot)) ?>"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Lihat Hasil Sementara</a>
										</div>
									<?php }else if($v->Calon < 1){ ?>
										<button type="button" class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2" onclick="swal('warning','Belum Ada Kandidat','warning')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</button>
									<?php }else{ ?>
										<a class="btn btn-sm btn-success text-light btn-block mb-2 mt-2 col-md-6" data-fancybox data-type="ajax" href="<?php echo site_url('Mahasiswa/get_hasil/'.encrypt_url($v->id_vot)) ?>"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Lihat Hasil</a>
									<?php } ?>
								</div>
							</div>
						</div><!--end card-body-->
					</div><!--end card-->
				</div>
			<?php } ?>
		<?php } ?>
		<?php $vote = $this->db->get_where('tbv_vote', 'idp_grp = "'.$g->id_grp.'"  AND (idp_jur = "'.$g->id_jur.'")')->result(); ?>
		<?php if ($vote != null){ ?>
			<?php foreach ($vote as $v){ ?>
				<div class="col-lg-6">
					<div class="card overflow-hidden">
						<div class="card-body bg-gradient<?= rand(1,3) ?>">
							<div class="">
								<div class="card-icon">
									<i class="far fa-user"></i>
								</div>
								<h2 class="font-weight-bold text-white"><?php echo $v->nama_vot ?></h2>
								<p class="text-white mb-0 font-16"><span class="badge badge-pill badge-danger"><?php echo $v->lingkup_vot ?></span> - <span class="badge badge-pill badge-info"><?php echo $g->nama_grp ?></span></p>                                            
							</div>
						</div>
						<div class="card-body dash-info-carousel">                                        
							<div class="text-center">
								<img src="<?= base_url() ?>mods/assets/images/logo-sm.png" alt="user" class="rounded-circle thumb-xl img-thumbnail mb-1">
								<h3><?php echo $v->Calon ?> Kandidat</h3>
								<p class="mb-0 text-muted" title=""><span class="badge badge-pill badge-danger"><?php echo date('d/m/Y H:i',strtotime($v->tgl_awal)) ?></span> - <span class="badge badge-pill badge-success"><?php echo date('d/m/Y H:i',strtotime($v->tgl_akhir)) ?></span></p>
								<p class="mt-2"><?php echo limitText($v->keterangan_vot) ?></p>
								<div class="mt-4 align-item-center">
									<?php if ($v->SisaHariAwal > 0){ ?>
										<a class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2" readonly="" href="javascript:void(0);" onclick="swal('warning','Tidak Bisa Melakukan Vote. Karena Belum Sesuai Tanggal','warning')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</a>
									<?php }else if($v->SisaHariAwal <= 0 AND $v->SisaHariAkhir >= 0){ ?>
										<div class="row">
											<a class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2 col-md-6" href="javascript:void(0);" onclick="get_vote('<?php echo encrypt_url($v->id_vot) ?>')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</a>
											
											<a  class="btn btn-sm btn-success text-light btn-block mb-2 mt-2 col-md-6" data-fancybox data-type="ajax" href="<?php echo site_url('Mahasiswa/get_hasil/'.encrypt_url($v->id_vot)) ?>"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Lihat Hasil Sementara</a>
										</div>
									<?php }else if($v->Calon < 1){ ?>
										<button type="button" class="btn btn-sm btn-primary text-light btn-block mb-2 mt-2" onclick="swal('warning','Belum Ada Kandidat','warning')"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Vote</button>
									<?php }else{ ?>
										<a class="btn btn-sm btn-success text-light btn-block mb-2 mt-2 col-md-6" data-fancybox data-type="ajax" href="<?php echo site_url('Mahasiswa/get_hasil/'.encrypt_url($v->id_vot)) ?>"><i class="mdi mdi-account-multiple-plus-outline mr-1"></i>Lihat Hasil</a>
									<?php } ?>
								</div>
							</div>
						</div><!--end card-body-->
					</div><!--end card-->
				</div>
			<?php } ?>
		<?php } ?>
	<?php } ?>
<?php }else{ ?>
	<div class="col-md-12">
		<div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-5 p-0 align-self-center">
                        <img src="<?= base_url() ?>mods/assets/images/error.svg" alt="" class="img-fluid">
                    </div>
                    <div class="col-md-7">
                        <div class="error-content text-center">
                            <h3 class="">🙌</h3>
                            <h3 class="text-primary">Data Group & Voting Tidak ditemukan</h3><br>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end card-body-->
        </div>
	</div>
<?php } ?>
</div>

<div class="modal fade" id="md_vote">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<h4 class="modal-title" style="color: white;">Vote</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<div class="modal-body" id="vote_body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="m_hasil">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<h4 class="modal-title" style="color: white;">Vote</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
				</button>
			</div>
			<div class="modal-body" id="m_body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
	function get_vote(arg)
	{
		$('#vote_body').html('');
		$.ajax({
			url: '<?php echo site_url('Mahasiswa/get_vote') ?>',
			type: 'POST',
			dataType: 'html',
			data: {arg: arg},
			success: function(data, textStatus, xhr)
			{
				$('#md_vote').modal('show');
				$('#vote_body').html(data);
			},
			error: function(xhr, textStatus, errorThrown)
			{
				swal('error',errorThrown,'error');
			}
		});
		
	}
	function get_hasil_vote(arg)
	{
		// postForm('get_hasil', {arg1: arg},'POST');
		// $('#m_body').html('');
		
		// $.ajax({
		// 	url: '<?php echo site_url('Mahasiswa/get_hasil') ?>',
		// 	type: 'POST',
		// 	dataType: 'html',
		// 	data: {arg: arg},
		// 	success: function(data, textStatus, xhr)
		// 	{
		// 		$('#m_body').html(data);
		// 		$('#m_hasil').modal('show');
		// 	},
		// 	error: function(xhr, textStatus, errorThrown)
		// 	{
		// 		swal('error',errorThrown,'error');
		// 	}
		// });
	}
</script>
