<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title><?= $title ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta content="A premium admin dashboard template by mannatthemes" name="description" />
		<meta content="Mannatthemes" name="author" />

		<!-- App favicon -->
		<link rel="shortcut icon" href="<?= base_url(); ?>mods/assets/images/logo-sm2.png">
		<link href="<?= base_url(); ?>mods/assets/plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
		<!--Morris Chart CSS -->
        <link rel="stylesheet" href="<?= base_url(); ?>mods/assets/plugins/morris/morris.css">
		<!-- DataTables -->
        <link href="<?= base_url(); ?>mods/assets/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= base_url(); ?>mods/assets/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="<?= base_url(); ?>mods/assets/plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" /> 
        <link href="<?= base_url(); ?>mods/assets/plugins/select2/select2.min.css" rel="stylesheet" type="text/css" />
		<!-- App css -->
		<link href="<?= base_url(); ?>mods/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="<?= base_url(); ?>mods/assets/css/icons.css" rel="stylesheet" type="text/css" />
		<link href="<?= base_url(); ?>mods/assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
		<link href="<?= base_url(); ?>mods/assets/css/style.css" rel="stylesheet" type="text/css" />

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css"/>
		<!-- jQuery  -->
		<script src="<?= base_url(); ?>mods/assets/js/jquery.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/bootstrap.bundle.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/metisMenu.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/waves.min.js"></script>
		<script src="<?= base_url(); ?>mods/assets/js/jquery.slimscroll.min.js"></script>

		
		 
		<style type="text/css" media="screen">
			.left-sidenav-menu li.active > a {
				background:#00001a1a ;
				/*color: #5766da;*/
			}
			.page-wrapper-img {
				/*background-image: url(../images/overlay.png);*/
				background-size: cover;
				background-position: center;
				min-height: 250px;
				-webkit-box-shadow: inset 0 0 0 2000px rgb(31 35 60 / 80%);
				box-shadow: inset 0 0 0 2000px rgb(31 35 60 / 55%);
			}
			.card-header{
				border-bottom: 5px solid #adadad;
			}
			.navbar-custom{
				background: white;
				border-bottom: 5px solid #adadad;
			}
			.left-sidenav-menu li > a:hover {
				background: #e5e5e852;
			}
			.bg-primary{
				background: #280b73 !important;
			}
			.sl2{
				width: 100% !important;
			}
			.modal-xx{
/*				max-width: 75%;*/
			}
		</style>	
		<!-- Sweet-Alert  -->
        <script src="<?= base_url(); ?>mods/assets/plugins/sweet-alert2/sweetalert2.min.js"></script>
        <script src="<?= base_url(); ?>mods/assets/pages/jquery.sweet-alert.init.js"></script>

         <!-- Required datatable js -->
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/jszip.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/pdfmake.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/vfs_fonts.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.html5.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.print.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/datatables/responsive.bootstrap4.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/pages/jquery.datatable.init.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/select2/select2.min.js"></script>

        <!--Morris Chart-->
        <script src="<?= base_url() ?>mods/assets/plugins/morris/morris.min.js"></script>
        <script src="<?= base_url() ?>mods/assets/plugins/raphael/raphael.min.js"></script>
        <!-- <script src="<?= base_url() ?>mods/assets/pages/jquery.morris.init.js"></script> -->
        <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
        <script>
        	function postForm(path, params, method) {
			    method = method || 'post';

			    var form = document.createElement('form');
			    form.setAttribute('method', method);
			    form.setAttribute('action', path);

			    for (var key in params) {
			        if (params.hasOwnProperty(key)) {
			            var hiddenField = document.createElement('input');
			            hiddenField.setAttribute('type', 'hidden');
			            hiddenField.setAttribute('name', key);
			            hiddenField.setAttribute('value', params[key]);

			            form.appendChild(hiddenField);
			        }
			    }

			    document.body.appendChild(form);
			    form.submit();
			}
        </script>
	</head>

	<body>

		<!-- Top Bar Start -->
		<div class="topbar">
			 <!-- Navbar -->
			 <nav class="navbar-custom">

				<!-- LOGO -->
				<div class="topbar-left">
					<a href="<?php echo site_url('Admin') ?>" class="logo">
						<span>
							<img src="<?= base_url(); ?>mods/assets/images/logo-sm.png" alt="logo-small" class="logo-sm">
						</span>
						<span>
							<img src="<?= base_url(); ?>mods/assets/images/logo-dark.png" alt="logo-large" class="logo-lg">
						</span>
					</a>
				</div>
	
				<ul class="list-unstyled topbar-nav float-right mb-0">
					<li class="dropdown">
						<a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
							aria-haspopup="false" aria-expanded="false">
							<img src="<?= base_url(); ?>mods/assets/images/users/user-1.jpg" alt="profile-user" class="rounded-circle" /> 
							<span class="ml-1 nav-user-name hidden-sm"> <i class="mdi mdi-chevron-down"></i> </span>
						</a>
						<div class="dropdown-menu dropdown-menu-right">
							<a class="dropdown-item" href="#" onclick="edit_password()"><i class="dripicons-lock text-muted mr-2"></i> Change Password</a>
							<div class="dropdown-divider"></div>
							<a class="dropdown-item" href="<?php echo site_url('Login/logout') ?>"><i class="dripicons-exit text-muted mr-2"></i> Logout</a>
						</div>
					</li>
				</ul>
	
				<ul class="list-unstyled topbar-nav mb-0">
					<li>
						<button class="button-menu-mobile nav-link waves-effect waves-light">
							<i class="mdi mdi-menu nav-icon"></i>
						</button>
					</li>

					
					
				</ul>

			</nav>
			<!-- end navbar-->
		</div>
		<!-- Top Bar End -->
		<div class="page-wrapper-img">
			<div class="page-wrapper-img-inner">
				<div class="sidebar-user media">
					<img src="<?= base_url(); ?>mods/assets/images/users/user-1.jpg" alt="user" class="rounded-circle img-thumbnail mb-1">
					<span class="online-icon"><i class="mdi mdi-record text-success"></i></span>
					<div class="media-body">
						<h5 class="text-light"><?php echo $this->session->userdata('nama'); ?></h5>
						<!--  -->
					</div>
				</div>
				<!-- Page-Title -->
				<div class="row">
					<div class="col-sm-12">
						<div class="page-title-box">
							<h4 class="page-title mb-2"><i class="mdi mdi-google-pages mr-2"></i><?php echo $title ?></h4>  
							<!--  -->                 
						</div><!--end page title box-->
					</div><!--end col-->
				</div><!--end row-->
				<!-- end page title end breadcrumb -->
			</div><!--end page-wrapper-img-inner-->
		</div><!--end page-wrapper-img-->
		
		<div class="page-wrapper">
			<div class="page-wrapper-inner">

				<!-- Left Sidenav -->
				<div class="left-sidenav">
					
					<ul class="metismenu left-sidenav-menu" id="side-nav">

						<li class="menu-title">Main</li>

						<li>
							<a href="<?php echo site_url('Mahasiswa') ?>"><i class="mdi mdi-monitor"></i><span>Dashboards</span></a>
						</li>
						<li class="menu-title">Components</li>
						
						
						<li>
							<a href="javascript: void(0);"><i class="mdi mdi-database"></i>Data Voting <span class="menu-arrow left-has-menu"><i class="mdi mdi-chevron-right"></i></span></a>
							<ul class="nav-second-level" aria-expanded="false">
								<li><a href="<?php echo site_url('Mahasiswa/voting') ?>"><i class="mdi mdi-table"></i>Voting</a></li>
								
							</ul>
						</li>
					</ul>
				</div>
				<!-- end left-sidenav-->
				<!-- Page Content-->
				<div class="page-content">
					<div class="container-fluid">
						<?php echo $this->session->flashdata('notif'); ?>
						<?php $this->load->view($content); ?>
					</div>
					<!-- container -->
					<footer class="footer text-center text-sm-left">
						&copy; <?php echo date('Y') ?> e-<strong>Voting</strong> <span class="text-muted d-none d-sm-inline-block float-right">Crafted with 💕 by CIA </span>
					</footer>
				</div>
				<!-- end page content -->
				
			</div>
			<!--end page-wrapper-inner -->
		</div>
		<!-- end page-wrapper -->
		<div class="modal fade" id="modal-edit-password">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Ubah Password</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							<span class="sr-only">Close</span>
						</button>
					</div>
					<form action="" id="frm_edit_password" method="post" accept-charset="utf-8">
						<div class="modal-body">
							<div class="col-md-12 form-group">
								<label class="required">Password Lama</label>
								<input type="password" required class="form-control" name="old_pass">
							</div>
							<div class="col-md-12 form-group">
								<label class="required">Password Baru</label>
								<input type="password" required class="form-control" name="new_pass">
							</div>
							
						<div id="error-message" style="color: red;"></div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary">Save changes</button>
						</div>
						
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->
		<!-- App js -->
		<script src="<?= base_url(); ?>mods/assets/js/app.js"></script>
		<script>
			$(document).ready(function() {
				$('.dtble').DataTable({"language": {"url": "<?php echo base_url() ?>mods/assets/plugins/datatables/id.json"},pagingType: 'numbers'});
				// $('body').addClass('enlarge-menu');
				$('.sl2').select2();
			});
			function edit_password()
			{
				$('#modal-edit-password').modal('show')
			}

			$('#frm_edit_password').submit(function(e) {
				e.preventDefault();
				$.ajax({
					url: '<?= site_url('Mahasiswa/edit_password') ?>',
					type: 'post',
					data: $(this).serializeArray(),
					dataType:'json',
					success: function(response) {
                if (response.stts === true) {
                    alert(response.message);
                    window.location = "<?= site_url('Login/logout') ?>"
                } else {
                    $('#error-message').text(response.message);
                }
            },
            error: function() {
                alert('Terjadi kesalahan saat mengirim permintaan.');
            }
				});
			});
		</script>
		<?php echo $this->session->flashdata('call'); ?>
	</body>
</html>