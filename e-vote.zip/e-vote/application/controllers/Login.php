<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		// $this->load->model('M_login');
	}

	function index()
	{
		if ($this->session->userdata('is_login') == true AND $this->session->userdata('role') == 'admin')
		{
			redirect('Admin');
		}
		else if ($this->session->userdata('is_login') == true AND $this->session->userdata('role') == 'mahasiswa')
		{
			redirect('Mahasiswa');
		}
		else if ($this->session->userdata('is_login') == true AND $this->session->userdata('role') == 'fakultas')
		{
			redirect('Fakultas');
		}
		else
		{
			$this->load->view('login');
		}
	}

	function login_fak()
	{
		if ($this->session->userdata('is_login') == true AND $this->session->userdata('role') == 'admin')
		{
			redirect('Admin');
		}
		else if ($this->session->userdata('is_login') == true AND $this->session->userdata('role') == 'mahasiswa')
		{
			redirect('Mahasiswa');
		}
		else if ($this->session->userdata('is_login') == true AND $this->session->userdata('role') == 'fakultas')
		{
			redirect('Fakultas');
		}
		else
		{
			$data['fakultas'] = $this->db->get('tbl_mas_fakultas')->result();
			$this->load->view('login_fak',$data);
		}
	}

	function login_proses()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$this->load->model('M_login','login');
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$where = array(
				'username' => $username,
				'password' => md5($password)
			);

			$cek = $this->login->cek('tbv_login', $where);
			if ($cek->num_rows() > 0)
			{
				$user = $cek->row();
				if ($user->StatusLogin == 'ON')
				{
					$this->session->set_flashdata('notif', '<div class="alert alert-warning alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button> <center>User Sedang Aktif <a href="' . site_url('reset/'.encrypt_url($user->IdLogin)).'" title="" >Klik Disini Untuk Reset</a></center></div>');
					redirect('Login');
				}
				else if($user->Role == 'admin' AND $user->StatusLogin == 'OFF')
				{
					$status = array(
						'StatusLogin' => 'ON',
						'LastLogin' =>  date('Y-m-d H:i:s'),
					);
					$where = array('IdLogin' => $user->IdLogin,);
					$this->db->update('tbl_login', $status, $where);

					$data_session = array(
						'iduser' => $user->IdLogin,
						'username' => $user->username,
						'nama' => $user->Nama,
						'idmahasiswa' => $user->IdMahasiswa,
						'NIM' => $user->NIM,
						'id_fak' => $user->id_fak,
						'id_jur' => $user->id_jur,
						'status' => $user->StatusLogin,
						'role' => $user->Role,
						'LastLogin' => $user->LastLogin,
						'is_login' => true,
					);

					$welcome = '<script>swal("Welcome to dashboard '.$user->username.'","Keep Smile 😘🙌👍","success");</script>';
					$this->session->set_userdata($data_session);
					$this->session->set_flashdata('notif', $welcome);
					redirect('Admin');
				}
				else if($user->Role == 'mahasiswa' AND $user->StatusLogin == 'OFF')
				{
					$status = array(
						'StatusLogin' => 'ON',
						'LastLogin' =>  date('Y-m-d H:i:s'),
					);
					$where = array('IdLogin' => $user->IdLogin,);
					$this->db->update('tbl_login', $status, $where);

					$data_session = array(
						'iduser' => $user->IdLogin,
						'username' => $user->username,
						'nama' => $user->Nama,
						'idmahasiswa' => $user->IdMahasiswa,
						'NIM' => $user->NIM,
						'id_fak' => $user->id_fak,
						'id_jur' => $user->id_jur,
						'status' => $user->StatusLogin,
						'role' => $user->Role,
						'LastLogin' => $user->LastLogin,
						'is_login' => true,
					);

					$welcome = '<script>swal("Welcome to dashboard '.$data_session['nama'].'","Keep Smile 😘🙌👍","success");</script>';
					$this->session->set_userdata($data_session);
					$this->session->set_flashdata('notif', $welcome);
					redirect('Mahasiswa');
				}
				else
				{
					$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Akun Anda Bermasalah</center></div>');
					redirect('Login');
				}
			}
			else
			{
				$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Username & Password Salah 😭😭</center></div>');
				redirect('Login');
			}
		}
		else
		{
			$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Request Method '.$this->input->server('REQUEST_METHOD').' Tidak Di Dukung 💩</center></div>');
			redirect('Login');
		}
	}

	function login_proses_fak()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$fak = decrypt_url($this->input->post('fak'));
			$password = $this->input->post('password');

			$where = array(
				'IdFak' => $fak,
				'password' => md5($password)
			);

			$cek = $this->db->get_where('tbv_login_fak', $where);
			if ($cek->num_rows() > 0)
			{
				$user = $cek->row();
				$data_session = array(
					'is_login' => true,
					'role' => 'fakultas', 
					'id_fak' => encrypt_url($user->IdFak), 
					'nama_fak' => $user->nama_fak
				);

				$welcome = '<script>swal("Welcome to dashboard '.$user->nama_fak.'","Keep Smile 😘🙌👍","success");</script>';
				$this->session->set_userdata($data_session);
				$this->session->set_flashdata('notif', $welcome);
				redirect('Fakultas');
			}
			else
			{
				$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Username & Password Salah 😭😭</center></div>');
				redirect('Login/login_fak');
			}
		}
		else
		{
			$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Request Method '.$this->input->server('REQUEST_METHOD').' Tidak Di Dukung 💩</center></div>');
			redirect('Login/login_fak');
		}
	}

	function reset($idlogin = false)
	{
		if ($idlogin != false)
		{
			$idlogin = decrypt_url($idlogin);
			$this->db->update('tbl_login', array('StatusLogin' => 'OFF'), array('IdLogin' => $idlogin));
			$this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissable" style="width:100%;"> <button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button> <center>Status Login Berhasil Di Reset 🙌</center></div>');
			redirect('Login');
		}
	}

	function logout()
	{
		$status = array('StatusLogin' => 'OFF');
		$where = array('IdLogin' => $this->session->userdata('iduser'),);
		$this->db->update('tbl_login', $status, $where);
		$this->session->sess_destroy();
		redirect('Login');
	}
}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */