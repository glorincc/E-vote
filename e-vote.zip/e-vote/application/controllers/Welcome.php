<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	function index()
	{
		$data['title'] = 'Mahasiswa';
		adminPage('index.html',$data);	
	}

	function tes()
	{
		$data = '[
					{
					"id": "1",
					"tipe": "GAJI POKOK",
					"total": 1400000,
					"kategori_gaji": "penerimaan"
					},
					{
					"id": "2",
					"tipe": "T. JABATAN",
					"total": 400000,
					"kategori_gaji": "penerimaan"
					},
					{
					"id": "3",
					"tipe": "T. Extra",
					"total": 200000,
					"kategori_gaji": "penerimaan"
					},
					{
					"id": "12",
					"tipe": "T. HARI TUA",
					"total": 100000,
					"kategori_gaji": "potongan"
					},
					{
					"id": "7",
					"tipe": "PPH PASAL 21",
					"total": 20000,
					"kategori_gaji": "potongan"
					}
				]';

		$data = json_decode($data,true);
		foreach ($data as $d)
		{
			// $potongan = array();
			// $penerimaan = array();
			if ($d['kategori_gaji'] == "potongan")
			{
				$datas['potongan'][] = array(
					'id' => $d['id'], 
					'tipe' => $d['tipe'], 
					'total' => $d['total'], 
				);
			}
			else if($d['kategori_gaji'] == "penerimaan")
			{
				$datas['penerimaan'][] = array(
					'id' => $d['id'], 
					'tipe' => $d['tipe'], 
					'total' => $d['total'], 	 
				);
			}	
		}


		$this->load->view('tes', $datas);
		// print_r($datas);

	}
}
