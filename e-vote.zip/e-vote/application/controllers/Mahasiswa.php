<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('encryption');
		if ($this->session->userdata('role') != 'mahasiswa') {
			$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Waktu Sesi Habis, Silakan Login Kembali</center></div>');
			redirect('login');
		}
	}

	public function index()
	{
		$data['title'] = 'Dashboard';
		$grp = $this->db->get_where('tbv_agt_grp','IdMahasiswa = "'.$this->session->userdata('idmahasiswa').'"');
		$jvote_grp = 0;
		$jvote_fak = 0;
		$jvote_jur = 0;
		foreach ($grp->result() as $g)
		{

			$fak_vote = (int)$this->db->query('SELECT COUNT(a.id_vot) AS TOTAL_VOTING FROM tbl_mas_vote a WHERE a.idp_grp = "'.$g->id_grp.'" AND (a.idp_fak = "'.$g->id_fak.'")')->row()->TOTAL_VOTING;
			$jvote_fak = (int)$jvote_fak + $fak_vote;

			$jur_vote = (int)$this->db->query('SELECT COUNT(a.id_vot) AS TOTAL_VOTING FROM tbl_mas_vote a WHERE a.idp_grp = "'.$g->id_grp.'" AND (a.idp_jur = "'.$g->id_jur.'")')->row()->TOTAL_VOTING;
			$jvote_jur = (int)$jvote_jur + $jur_vote;

			$grp_vote = (int)$this->db->query('SELECT COUNT(a.id_vot) AS TOTAL_VOTING FROM tbl_mas_vote a WHERE a.idp_grp = "'.$g->id_grp.'" AND (a.idp_fak = 0 AND a.idp_jur = 0)')->row()->TOTAL_VOTING;
			$jvote_grp = (int)$jvote_grp + $grp_vote;
		}
		
		$data['t_vote_grp'] = $jvote_grp;
		$data['t_vote_fak'] = $jvote_fak;
		$data['t_vote_jur'] = $jvote_jur;
		// print_r($data['t_vote'].'-'.$this->session->userdata('idmahasiswa'));
		render('mahasiswa/home',$data);
	}

	function voting()
	{
		$data['title'] = 'Voting';
		$data['grp'] = $this->db->get_where('tbv_agt_grp','IdMahasiswa = "'.$this->session->userdata('idmahasiswa').'"')->result();
		
		render('mahasiswa/voting',$data);
	}


	function get_vote()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$idvote = decrypt_url($this->input->post('arg'));
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$idvote.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$data['kandidat'] = $this->db->get_where('tbv_kandidat','id_vot = "'.$idvote.'"')->result();
				$stts_vote = $this->db->get_where('tbl_res_vote','id_vot = "'.$idvote.'" AND vote_by = "'.$this->session->userdata('idmahasiswa').'"');
				if ($stts_vote->num_rows() > 0)
				{
					$data['status'] = false;
				}
				else
				{
					$data['status'] = true;
				}

				$this->load->view('ajx/v_vote', $data);
			}
			else
			{
				http_response_code(404);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function vote_kandidat($kandidat = false, $vote = false)
	{
		if ($kandidat != false or $vote != false)
		{
			$kandidat = decrypt_url($kandidat);
			$idvote = decrypt_url($vote);
			$stts_vote = $this->db->get_where('tbl_res_vote','id_vot = "'.$idvote.'" AND vote_by = "'.$this->session->userdata('idmahasiswa').'"');
			if ($stts_vote->num_rows() > 0)
			{
				http_response_code(403);
			}
			else
			{
				$data = array(
					'id_vot' => $idvote, 
					'id_kandidat' => $kandidat, 
					'vote_by' => $this->session->userdata('idmahasiswa'), 
				);

				$this->db->insert('tbl_res_vote', $data);
				$this->session->set_flashdata('notif', '<script>swal("Success","Berhasil","success");</script>');
				$this->session->set_flashdata('call', '<script>get_vote("'.encrypt_url($idvote).'");</script>');
				redirect('Mahasiswa/voting');

			}
		}
		else
		{
			http_response_code(404);
		}
	}


	function get_hasil($arg = false)
	{
		if ($arg != false)
		{
			// $idvote = 6;
			$idvote = decrypt_url($arg);
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$idvote.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$data['res'] =  $this->db->select('Nama AS label,RES_TOTAL AS value,Nama, NIM,bobot,Total_vote')->get_where('res_count_vote', 'id_vot = "'.$idvote.'"')->result();
				// end($data['res']);
				// $last_key = key($data['res']);;
				// adminPage('ajx/v_adm_vote',$data);
				$this->load->view('ajx/v_adm_vote', $data);
			}
			else
			{
				http_response_code(403);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	public function edit_password()
{
    if ($this->input->server('REQUEST_METHOD') == 'POST')
    {
        $old_password = md5($this->input->post('old_pass'));
        $new_password = md5($this->input->post('new_pass'));

        // Validasi password baru tidak sama dengan password lama
        if ($old_password === $new_password) {
            echo json_encode(array(
                'stts' => false,
                'message' => 'Password baru tidak boleh sama dengan password lama',
            ));
            return;
        }

        $user_id = $this->session->userdata('idmahasiswa');

        // Validasi password lama
        $cek = $this->db->get_where('tbl_login', array('password' => $old_password, 'IdMahasiswa' => $user_id));
        if ($cek->num_rows() > 0)
        {
            // Update password
            $update = $this->db->update('tbl_login', array('password' => $new_password,), array('IdMahasiswa' => $user_id,));

            echo json_encode(array(
                'stts' => true,
                'message' => 'Password berhasil diperbarui silahkan login kembali!',
            ));
        }
        else
        {
            echo json_encode(array(
                'stts' => false,
                'message' => 'Password lama tidak sesuai',
            ));
        }
    }
    else
    {
        http_response_code(404);
    }
}

	
}

/* End of file Mahasiswa.php */
/* Location: ./application/controllers/Mahasiswa.php */