<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fakultas extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('encryption');
		if ($this->session->userdata('role') != 'fakultas') {
			$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Waktu Sesi Habis, Silakan Login Kembali</center></div>');
			redirect('Login/login_fak');
		}
	}

	public function index()
	{
		$data['title'] = 'Dashboard '.$this->session->userdata('nama_fak');
		$data['c_mahasiswa'] = $this->db->get_where('tbv_mahasiswa','id_fak = "'.decrypt_url($this->session->userdata('id_fak')).'"')->num_rows();
		$data['c_jur'] = $this->db->get_where('tbl_mas_jurusan','id_fak = "'.decrypt_url($this->session->userdata('id_fak')).'"')->num_rows();
		$data['c_grp'] = $this->db->get('tbl_mas_group')->num_rows();
		$data['c_vote'] = $this->db->get_where('tbl_mas_vote','idp_fak = "'.decrypt_url($this->session->userdata('id_fak')).'"')->num_rows();
		render_fak('fakultas/home',$data);
	}

	function voting()
	{
		$data['title'] = 'Data Voting';
		$data['voting'] = $this->db->get_where('tbv_vote','idp_fak = "'.decrypt_url($this->session->userdata('id_fak')).'" or idp_jur IN (SELECT id_jur FROM tbl_mas_jurusan WHERE id_fak = "'.decrypt_url($this->session->userdata('id_fak')).'")')->result();
		$data['group'] = $this->db->get('tbl_mas_group')->result();
		$data['jurusan'] = $this->db->get_where('tbl_mas_jurusan','id_fak = "'.decrypt_url($this->session->userdata('id_fak')).'"')->result();
		$data['fakultas'] = $this->db->get('tbl_mas_fakultas')->result();
 		render_fak('fakultas/voting',$data);
	}


	function get_calon()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$id_vot = decrypt_url($this->input->post('arg'));
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$id_vot.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$type= $this->input->post('arg2');
				if ($type == 'fak')
				{
					$fak = decrypt_url($this->input->post('arg1'));
					$data['mahasiswa'] = $this->db->get_where('tbv_agt_grp','id_fak = "'.$fak.'" AND id_grp = "'.$data['vote']->idp_grp.'"')->result();
					$data['kandidat'] =  $this->db->get_where('tbv_kandidat','id_vot = "'.$id_vot.'" AND id_fak = "'.$fak.'"')->result();	
				}
				else if($type == 'jur')
				{
					$jur = decrypt_url($this->input->post('arg1'));
					$data['mahasiswa'] = $this->db->get_where('tbv_agt_grp','id_jur = "'.$jur.'" AND id_grp = "'.$data['vote']->idp_grp.'"')->result();
					$data['kandidat'] =  $this->db->get_where('tbv_kandidat','id_vot = "'.$id_vot.'" AND id_jur = "'.$jur.'"')->result();
				}
				else
				{
					$data['mahasiswa'] = $this->db->get_where('tbv_agt_grp','id_grp = "'.$data['vote']->idp_grp.'"')->result();
					$data['kandidat'] =  $this->db->get_where('tbv_kandidat','id_vot = "'.$id_vot.'"')->result();	
				}
				
				$this->load->view('ajx/add_kandidat_fak',$data);
			}
			else
			{
				http_response_code(404);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function simpan_kandidat()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$id_vote = decrypt_url($this->input->post('vote'));
			$result = array();
			foreach ($_POST['kandidat'] as $key => $val)
			{
				$cek = $this->db->get_where('tbl_vote_kandidat','IdMahasiswa = "'.decrypt_url($_POST['kandidat'][$key]).'" and id_vot = "'.$id_vote.'"');
				if ($cek->num_rows() > 0)
				{
					continue;
				}
				else
				{
					$result[] = array(
						'id_vot' => $id_vote,
						'IdMahasiswa' => decrypt_url($_POST['kandidat'][$key]) 
					);
				}
			}

			if (count($result) > 0)
			{
				$this->db->insert_batch('tbl_vote_kandidat', $result);
				$this->session->set_flashdata('notif', '<script>swal("Success","Kandidat berhasil ditambahkan","success");</script>');
				$this->session->set_flashdata('call', '<script>calon("'.encrypt_url($id_vote).'");</script>');
				redirect('Fakultas/voting');
			}
			else
			{
				$this->session->set_flashdata('notif', '<script>swal("Error","Kandidat gagal ditambahkan","error");</script>');
				$this->session->set_flashdata('call', '<script>calon("'.encrypt_url($id_vote).'");</script>');
				redirect('Fakultas/voting');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_kandidat($id_kandidat = false,$id_vote=false)
	{
		if ($id_kandidat != false or $id_vote != false)
		{

			$id_kandidat = decrypt_url($id_kandidat);
			$this->db->delete('tbl_vote_kandidat',array('id_kandidat' => $id_kandidat,));
			$this->session->set_flashdata('notif', '<script>swal("Success","Kandidat berhasil dihapus","success");</script>');
			$this->session->set_flashdata('call', '<script>calon("'.$id_vote.'");</script>');
			redirect('Fakultas/voting');
		}
	}

	function simpan_edit_vote()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$topik = $this->input->post('topik');
			$lingkup = $this->input->post('lingkup');
			$grp = decrypt_url($this->input->post('grp'));
			$keterangan = $this->input->post('keterangan');
			$tgl1 = $this->input->post('tawal');
			$tgl2 = $this->input->post('takhir');
			$id = decrypt_url($this->input->post('vote'));
			$idp_fak = decrypt_url($this->input->post('fak'));
			$idp_jur = decrypt_url($this->input->post('jur'));

			if ($idp_fak != 0 and $lingkup == 'Fakultas')
			{
				$idp_jur = 0;
			}
			else if($idp_jur != 0 and $lingkup == 'Jurusan')
			{
				$idp_fak = 0;
			}
			else
			{
				$idp_jur = 0;
				$idp_fak = 0;
			}

			$data = array(
				'nama_vot' => $topik, 
				'lingkup_vot' => $lingkup, 
				'idp_jur' => $idp_jur, 
				'idp_fak' => $idp_fak, 
				'idp_grp' => $grp, 
				'tgl_awal' => $tgl1, 
				'tgl_akhir' => $tgl2, 
				'keterangan_vot' => $keterangan, 
			);

			$update = $this->db->update('tbl_mas_vote', $data,array('id_vot' => $id, ));
			$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil disimpan","success");</script>');
			redirect('Fakultas/voting');
		}
	}

	function simpan_vote()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$topik = $this->input->post('topik');
			$lingkup = $this->input->post('lingkup');
			$grp = decrypt_url($this->input->post('grp'));
			$keterangan = $this->input->post('keterangan');
			$tgl1 = $this->input->post('tawal');
			$tgl2 = $this->input->post('takhir');
			// var_dump($tgl1);
			// var_dump($tgl2);
			// exit();
			$fak = decrypt_url($this->input->post('fak'));
			$jur = decrypt_url($this->input->post('jur'));
			$data = array(
				'nama_vot' => $topik, 
				'lingkup_vot' => $lingkup, 
				'idp_grp' => $grp, 
				'idp_fak' => $fak, 
				'idp_jur' => $jur, 
				'tgl_awal' => $tgl1, 
				'tgl_akhir' => $tgl2, 
				'keterangan_vot' => $keterangan, 
			);

			$insert = $this->db->insert('tbl_mas_vote', $data);
			if ($insert)
			{
				$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil ditambahkan","success");</script>');
				redirect('Fakultas/voting');
			}	
			else
			{
				$this->session->set_flashdata('notif', '<script>swal("error","Vote gagal ditambahkan","error");</script>');
				redirect('Fakultas/voting');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function status_vote($stts = false,$id_vote = false)
	{
		if ($stts != false or $id_vote != false)
		{
			$id_vote = decrypt_url($id_vote);
			$stts = decrypt_url($stts);
			if ($stts == 0)
			{
				$this->db->update('tbl_mas_vote', array('status_vot' => $stts,),array('id_vot' => $id_vote,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil diupdate","success");</script>');
				redirect('Fakultas/voting');
			}
			else if($stts == 1)
			{
				$this->db->update('tbl_mas_vote', array('status_vot' => $stts,),array('id_vot' => $id_vote,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil diupdate","success");</script>');
				redirect('Fakultas/voting');
			}
			else
			{
				http_response_code(404);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_vote($idvote=false)
	{
		if ($idvote != false)
		{
			$idvote = decrypt_url($idvote);
			$this->db->delete('tbl_mas_vote',array('id_vot' => $idvote,));
			$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil dihapus","success");</script>');
			redirect('Fakultas/voting');
		}
		else
		{
			http_response_code(404);
		}
	}

	function get_hasil()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			// $idvote = 6;
			$idvote = decrypt_url($this->input->post('arg'));
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$idvote.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$data['res'] =  $this->db->select('Nama AS label,RES_TOTAL AS value,Nama, NIM,bobot,Total_vote')->get_where('res_count_vote', 'id_vot = "'.$idvote.'"')->result();
				// end($data['res']);
				// $last_key = key($data['res']);;
				// render_fak('ajx/v_adm_vote',$data);
				$this->load->view('ajx/v_adm_vote', $data);
			}
			else
			{
				http_response_code(403);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

}

/* End of file Fakultas.php */
/* Location: ./application/controllers/Fakultas.php */