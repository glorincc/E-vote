<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('encryption');
		if ($this->session->userdata('role') != 'admin') {
			$this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissable" style=""><button type="button" data-dismiss="alert" aria-hidden="true" class="close">&times;</button><center>Waktu Sesi Habis, Silakan Login Kembali</center></div>');
			redirect('login');
		}
	}
	public function index()
	{
		$data['title'] = 'Dashboard Admin';
		$data['c_mahasiswa'] = $this->db->get('tbv_mahasiswa')->num_rows();
		$data['c_fak'] = $this->db->get('tbl_mas_group')->num_rows();
		$data['c_grp'] = $this->db->get('tbl_mas_group')->num_rows();
		$data['c_vote'] = $this->db->get('tbl_mas_vote')->num_rows();
		adminPage('admin/home',$data);
	}

	function get_jur()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$id_fak = decrypt_url($this->input->post('fak'));
			$jur = $this->db->get_where('tbl_mas_jurusan','id_fak = "'.$id_fak.'"')->result();
			$result = array();
			foreach ($jur as $j)
			{
				$result[] = array(
					'id_jur' => encrypt_url($j->id_jur), 
					'nama_jur' => $j->nama_jur, 
				);
			}

			echo json_encode($result);
		}
	}

	function mahasiswa()
	{
		$data['title'] = 'Mahasiswa';
		$data['mahasiswa'] = $this->db->get('tbv_mahasiswa')->result();
		$data['fak'] = $this->db->get('tbl_mas_fakultas')->result();
		adminPage('admin/mahasiswa',$data);
	}


	function simpan_mahasiswa()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$nim = $this->input->post('nim');	
			$nama = $this->input->post('nama');	
			$fakultas = decrypt_url($this->input->post('fakultas'));	
			$jurusan = decrypt_url($this->input->post('jurusan'));	
			$jk = $this->input->post('jk');	
			$masuk = $this->input->post('masuk');	
			$tgl_lahir = $this->input->post('tgl_lahir');	
			$nohp = $this->input->post('nohp');	
			$email = $this->input->post('email');

			$data = array(
				'NIM' => $nim, 
				'Nama' => $nama, 
				'id_jur' => $jurusan, 
				'JK' => $jk, 
				'Tahun_Masuk' => $masuk, 
				'Tgl_Lahir' => $tgl_lahir, 
				'NoHP' => $nohp, 
				'Email' => $email, 
			);

			$cek = $this->db->get_where('tbl_mas_mahasiswa', 'NIM = "'.$nim.'"')->num_rows();
			if ($cek > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss","NIM : '.$nim.' Sudah terdaftar","error")</script>');
				redirect('Admin/mahasiswa');
			}
			else
			{
				$this->db->insert('tbl_mas_mahasiswa', $data);
				$this->session->set_flashdata('notif', '<script>swal("Success","Data berhasil disimpan","success")</script>');
				redirect('Admin/mahasiswa');
			}
		}
	}

	function get_edit_mahasiswa()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST' AND !empty($this->input->post('arg')))
		{
			$idmahasiswa = decrypt_url($this->input->post('arg'));
			$data['mahasiswa'] = $this->db->get_where('tbv_mahasiswa','IdMahasiswa = "'.$idmahasiswa.'"')->row();
			$data['fak'] = $this->db->get_where('tbl_mas_fakultas','id_fak != "'.$data['mahasiswa']->id_fak.'"')->result();
			$data['jur'] = $this->db->get_where('tbl_mas_jurusan','id_fak = "'.$data['mahasiswa']->id_fak.'" AND id_jur != "'.$data['mahasiswa']->id_jur.'"')->result();
			$this->load->view('ajx/get_mahasiswa_edit',$data);
		}
		else
		{
			http_response_code(404);
		}
	}

	function simpan_edit_mahasiswa()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$idmahasiswa = decrypt_url($this->input->post('idmahasiswa'));	
			$nim = $this->input->post('nim');	
			$nama = $this->input->post('nama');	
			$fakultas = decrypt_url($this->input->post('fakultas'));	
			$jurusan = decrypt_url($this->input->post('jurusan'));	
			$jk = $this->input->post('jk');	
			$masuk = $this->input->post('masuk');	
			$tgl_lahir = $this->input->post('tgl_lahir');	
			$nohp = $this->input->post('nohp');	
			$email = $this->input->post('email');

			$data = array(
				'NIM' => $nim,
				'Nama' => $nama,
				'id_jur' => $jurusan,
				'JK' => $jk,
				'Tahun_Masuk' => $masuk,
				'Tgl_Lahir' => $tgl_lahir,
				'NoHP' => $nohp,
				'Email' => $email,
			);

			$cek = $this->db->get_where('tbl_mas_mahasiswa', 'NIM = "'.$nim.'" AND IdMahasiswa != "'.$idmahasiswa.'"')->num_rows();
			if ($cek > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss","NIM : '.$nim.' Sudah terdaftar","error")</script>');
				redirect('Admin/mahasiswa');
			}
			else
			{
				$this->db->update('tbl_mas_mahasiswa', $data,array('IdMahasiswa' => $idmahasiswa,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Data berhasil diupdate","success")</script>');
				redirect('Admin/mahasiswa');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_mahasiswa($idmahasiswa = false)
	{
		if ($idmahasiswa != false)
		{
			$idmahasiswa = decrypt_url($idmahasiswa);
			$this->db->delete('tbl_mas_mahasiswa','IdMahasiswa = "'.$idmahasiswa.'"');
			$this->session->set_flashdata('notif', '<script>swal("Success","Data berhasil dihapus","success")</script>');
			redirect('Admin/mahasiswa');
		}
		else
		{
			http_response_code(404);
		}
	}

	function fakultas()
	{
		$data['title'] = 'Fakultas';
		$data['fak'] = $this->db->get('tbl_mas_fakultas')->result();
		adminPage('admin/fakultas',$data);
	}

	function simpan_fakultas()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$fakultas = $this->input->post('fakultas');
			$data = array('nama_fak' => $fakultas,);
			$cek = $this->db->get_where('tbl_mas_fakultas',$data);
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss",`Nama Fakultas : "'.$fakultas.'" Sudah terdaftar`,"error")</script>');
				redirect('Admin/fakultas');
			}
			else
			{
				$this->db->insert('tbl_mas_fakultas', $data);
				$this->session->set_flashdata('notif', '<script>swal("Success","Fakultas berhasil disimpan","success")</script>');
				redirect('Admin/fakultas');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function simpan_edit_fakultas()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$fakultas = $this->input->post('fakultas');
			$fak = decrypt_url($this->input->post('fak'));
			$data = array('nama_fak' => $fakultas,);
			$cek = $this->db->get_where('tbl_mas_fakultas','nama_fak = "'.$fakultas.'" AND id_fak != "'.$fak.'"');
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss",`Nama Fakultas : "'.$fakultas.'" Sudah terdaftar`,"error")</script>');
				redirect('Admin/fakultas');
			}
			else
			{
				$this->db->update('tbl_mas_fakultas', $data,array('id_fak' => $fak,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Fakultas berhasil disimpan","success")</script>');
				redirect('Admin/fakultas');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_fakultas($id_fak = false)
	{
		if ($id_fak != false)
		{
			$id_fak = decrypt_url($id_fak);
			$this->db->delete('tbl_mas_fakultas','id_fak = "'.$id_fak.'"');
			$this->session->set_flashdata('notif', '<script>swal("Success","Fakultas berhasil dihapus","success")</script>');
			redirect('Admin/fakultas');
		}
		else
		{
			http_response_code(404);
		}
	}

	function jurusan()
	{
		$data['title'] = 'Prodi';
		$data['fak'] = $this->db->get('tbl_mas_fakultas')->result();
		$data['jur'] = $this->db->get('tbv_jurusan')->result();
		adminPage('admin/jurusan',$data);
	}

	function simpan_jurusan()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$jurusan = $this->input->post('jurusan');
			$fakultas = decrypt_url($this->input->post('fakultas'));
			$data = array(
				'nama_jur' => $jurusan,
				'id_fak' => $fakultas,
			);
			$cek = $this->db->get_where('tbl_mas_jurusan',$data);
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss",`Nama Jurusan : "'.$jurusan.'" Sudah terdaftar`,"error")</script>');
				redirect('Admin/jurusan');
			}
			else
			{
				$this->db->insert('tbl_mas_jurusan', $data);
				$this->session->set_flashdata('notif', '<script>swal("Success","Jurusan berhasil disimpan","success")</script>');
				redirect('Admin/jurusan');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function simpan_edit_jurusan()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$jurusan = $this->input->post('jurusan');
			$id_jur = decrypt_url($this->input->post('jur'));
			$fakultas = decrypt_url($this->input->post('fakultas'));
			$data = array(
				'nama_jur' => $jurusan,
				'id_fak' => $fakultas,
			);
			$cek = $this->db->get_where('tbl_mas_jurusan','nama_jur = "'.$jurusan.'" AND id_fak = "'.$fakultas.'" AND id_jur !="'.$id_jur.'"');
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss",`Nama Jurusan : "'.$jurusan.'" Sudah terdaftar`,"error")</script>');
				redirect('Admin/jurusan');
			}
			else
			{
				$this->db->update('tbl_mas_jurusan', $data,array('id_jur' => $id_jur,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Jurusan berhasil disimpan","success")</script>');
				redirect('Admin/jurusan');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_jurusan($id_jur = false)
	{
		if ($id_jur != false)
		{
			$id_jur = decrypt_url($id_jur);
			$this->db->delete('tbl_mas_jurusan','id_jur = "'.$id_jur.'"');
			$this->session->set_flashdata('notif', '<script>swal("Success","Prodi berhasil dihapus","success")</script>');
			redirect('Admin/jurusan');
		}
		else
		{
			http_response_code(404);
		}
	}

	function group()
	{
		$data['title'] = 'Data Group';
		// $data['group'] = $this->db->get('tbl_mas_group')->result();
		// $data['group'] = NULL;
 		adminPage('admin/group',$data);
	}

	function ajx_grp()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$data['group'] = $this->db->get('tbl_mas_group')->result();
			$this->load->view('admin/ajx_grp', $data);
		}
	}


	function simpan_group()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$nama_grp = $this->input->post('nama_grp');
			$ket_grp = $this->input->post('keterangan_grp');

			$data = array(
				'nama_grp' => $nama_grp,
				'keterangan_grp' => $ket_grp,
			);

			$cek = $this->db->get_where('tbl_mas_group', 'nama_grp = "'.$nama_grp.'"');
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss",`Nama Group : "'.$nama_grp.'" Sudah terdaftar`,"error")</script>');
				redirect('Admin/group');
			}
			else
			{
				$this->db->insert('tbl_mas_group', $data);
				$this->session->set_flashdata('notif', '<script>swal("Success","Group berhasil disimpan","success")</script>');
				redirect('Admin/group');
			}
		}
	}

	function simpan_edit_group()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$nama_grp = $this->input->post('nama_grp');
			$ket_grp = $this->input->post('keterangan_grp');
			$idgrp= decrypt_url($this->input->post('grp'));
			$data = array(
				'nama_grp' => $nama_grp,
				'keterangan_grp' => $ket_grp,
			);

			$cek = $this->db->get_where('tbl_mas_group', 'nama_grp = "'.$nama_grp.'" AND id_grp != "'.$idgrp.'"');
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("Opss",`Nama Group : "'.$nama_grp.'" Sudah terdaftar`,"error")</script>');
				redirect('Admin/group');
			}
			else
			{
				$this->db->update('tbl_mas_group', $data,array('id_grp' => $idgrp,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Group berhasil disimpan","success")</script>');
				redirect('Admin/group');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_grp($id_grp = false)
	{
		if ($id_grp != false)
		{
			$id_grp = decrypt_url($id_grp);
			$this->db->delete('tbl_mas_group',array('id_grp' => $id_grp,));
			$this->session->set_flashdata('notif', '<script>swal("Success","Group berhasil dihapus","success")</script>');
			redirect('Admin/group');
		}
		else
		{
			http_response_code(404);
		}
	}

	function get_agt()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$idgrp = decrypt_url($this->input->post('arg'));
			$data['grp'] = $this->db->get_where('tbl_mas_group','id_grp = "'.$idgrp.'"')->row();
			$data['anggota'] = $this->db->get_where('tbv_agt_grp', 'id_grp = "'.$idgrp.'"')->result();
			$data['mahasiswa'] = $this->db->get('tbv_mahasiswa')->result();

			$this->load->view('admin/ajx_agt', $data);
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_agt($id_agt = false,$id_grp = false)
	{
		if ($id_agt != false or $id_grp != false)
		{
			$id_agt = decrypt_url($id_agt);
			$id_grp = decrypt_url($id_grp);
			$this->db->delete('tbl_agt_grp',array('id_agt' => $id_agt,));
			$this->session->set_flashdata('notif', '<script>swal("Success","Group berhasil dihapus","success");</script>');
			$this->session->set_flashdata('call', '<script>get_agt("'.encrypt_url($id_grp).'");</script>');
			redirect('Admin/group');
		}
		else
		{
			http_response_code(404);
		}
	}

	function tambah_anggota()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$id_grp = decrypt_url($this->input->post('id_grp'));
			$idmahasiswa = decrypt_url($this->input->post('mahasiswa'));

			$data = array(
				'id_grp' => $id_grp, 
				'IdMahasiswa' => $idmahasiswa, 
			);

			$cek = $this->db->get_where('tbl_agt_grp', $data);
			if ($cek->num_rows() > 0)
			{
				$this->session->set_flashdata('notif', '<script>swal("error","Mahasiswa sudah terdaftar di group ini","error");</script>');
				$this->session->set_flashdata('call', '<script>get_agt("'.encrypt_url($id_grp).'");</script>');
				redirect('Admin/group');
			}
			else
			{
				$this->db->insert('tbl_agt_grp', $data);
				$this->session->set_flashdata('notif', '<script>swal("Success","Mahasiswa berhasil ditambahkan","success");</script>');
				$this->session->set_flashdata('call', '<script>get_agt("'.encrypt_url($id_grp).'");</script>');
				redirect('Admin/group');
			}
		}
	}

	function voting()
	{
		$data['title'] = 'Data Voting';
		$data['voting'] = $this->db->get('tbv_vote')->result();
		$data['group'] = $this->db->get('tbl_mas_group')->result();
		$data['jurusan'] = $this->db->get('tbl_mas_jurusan')->result();
		$data['fakultas'] = $this->db->get('tbl_mas_fakultas')->result();
 		adminPage('admin/voting',$data);
	}

	function simpan_vote()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$topik = $this->input->post('topik');
			$lingkup = $this->input->post('lingkup');
			$grp = decrypt_url($this->input->post('grp'));
			$keterangan = $this->input->post('keterangan');
			$tgl1 = $this->input->post('tawal');
			$tgl2 = $this->input->post('takhir');
			// var_dump($tgl1);
			// var_dump($tgl2);
			// exit();
			$fak = decrypt_url($this->input->post('fak'));
			$jur = decrypt_url($this->input->post('jur'));
			$data = array(
				'nama_vot' => $topik, 
				'lingkup_vot' => $lingkup, 
				'idp_grp' => $grp, 
				'idp_fak' => $fak, 
				'idp_jur' => $jur, 
				'tgl_awal' => $tgl1, 
				'tgl_akhir' => $tgl2, 
				'keterangan_vot' => $keterangan, 
			);
			$insert = $this->db->insert('tbl_mas_vote', $data);
			if ($insert)
			{
				$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil ditambahkan","success");</script>');
				redirect('Admin/voting');
			}	
			else
			{
				$this->session->set_flashdata('notif', '<script>swal("error","Vote gagal ditambahkan","error");</script>');
				redirect('Admin/voting');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function status_vote($stts = false,$id_vote = false)
	{
		if ($stts != false or $id_vote != false)
		{
			$id_vote = decrypt_url($id_vote);
			$stts = decrypt_url($stts);
			if ($stts == 0)
			{
				$this->db->update('tbl_mas_vote', array('status_vot' => $stts,),array('id_vot' => $id_vote,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil diupdate","success");</script>');
				redirect('Admin/voting');
			}
			else if($stts == 1)
			{
				$this->db->update('tbl_mas_vote', array('status_vot' => $stts,),array('id_vot' => $id_vote,));
				$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil diupdate","success");</script>');
				redirect('Admin/voting');
			}
			else
			{
				http_response_code(404);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_vote($idvote=false)
	{
		if ($idvote != false)
		{
			$idvote = decrypt_url($idvote);
			$this->db->delete('tbl_mas_vote',array('id_vot' => $idvote,));
			$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil dihapus","success");</script>');
			redirect('Admin/voting');
		}
		else
		{
			http_response_code(404);
		}
	}

	function get_calon()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$id_vot = decrypt_url($this->input->post('arg'));
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$id_vot.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$type= $this->input->post('arg2');
				if ($type == 'fak')
				{
					$fak = decrypt_url($this->input->post('arg1'));
					$data['mahasiswa'] = $this->db->get_where('tbv_agt_grp','id_fak = "'.$fak.'" AND id_grp = "'.$data['vote']->idp_grp.'"')->result();
					$data['kandidat'] =  $this->db->get_where('tbv_kandidat','id_vot = "'.$id_vot.'" AND id_fak = "'.$fak.'"')->result();	
				}else if($type == 'jur')
				{
					$jur = decrypt_url($this->input->post('arg1'));
					$data['mahasiswa'] = $this->db->get_where('tbv_agt_grp','id_jur = "'.$jur.'" AND id_grp = "'.$data['vote']->idp_grp.'"')->result();
					$data['kandidat'] =  $this->db->get_where('tbv_kandidat','id_vot = "'.$id_vot.'" AND id_jur = "'.$jur.'"')->result();
				}
				else
				{
					$data['mahasiswa'] = $this->db->get_where('tbv_agt_grp','id_grp = "'.$data['vote']->idp_grp.'"')->result();
					$data['kandidat'] =  $this->db->get_where('tbv_kandidat','id_vot = "'.$id_vot.'"')->result();	
				}
				
				$this->load->view('ajx/add_kandidat',$data);
			}
			else
			{
				http_response_code(404);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function simpan_kandidat()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$id_vote = decrypt_url($this->input->post('vote'));
			$result = array();
			foreach ($_POST['kandidat'] as $key => $val)
			{
				$cek = $this->db->get_where('tbl_vote_kandidat','IdMahasiswa = "'.decrypt_url($_POST['kandidat'][$key]).'" and id_vot = "'.$id_vote.'"');
				if ($cek->num_rows() > 0)
				{
					continue;
				}
				else
				{
					$result[] = array(
						'id_vot' => $id_vote,
						'IdMahasiswa' => decrypt_url($_POST['kandidat'][$key]) 
					);
				}
			}

			if (count($result) > 0)
			{
				$this->db->insert_batch('tbl_vote_kandidat', $result);
				$this->session->set_flashdata('notif', '<script>swal("Success","Kandidat berhasil ditambahkan","success");</script>');
				$this->session->set_flashdata('call', '<script>calon("'.encrypt_url($id_vote).'");</script>');
				redirect('Admin/voting');
			}
			else
			{
				$this->session->set_flashdata('notif', '<script>swal("Error","Kandidat gagal ditambahkan","error");</script>');
				$this->session->set_flashdata('call', '<script>calon("'.encrypt_url($id_vote).'");</script>');
				redirect('Admin/voting');
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hapus_kandidat($id_kandidat = false,$id_vote=false)
	{
		if ($id_kandidat != false or $id_vote != false)
		{

			$id_kandidat = decrypt_url($id_kandidat);
			$this->db->delete('tbl_vote_kandidat',array('id_kandidat' => $id_kandidat,));
			$this->session->set_flashdata('notif', '<script>swal("Success","Kandidat berhasil dihapus","success");</script>');
			$this->session->set_flashdata('call', '<script>calon("'.$id_vote.'");</script>');
			redirect('Admin/voting');
		}
	}

	function simpan_edit_vote()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			$topik = $this->input->post('topik');
			$lingkup = $this->input->post('lingkup');
			$grp = decrypt_url($this->input->post('grp'));
			$keterangan = $this->input->post('keterangan');
			$tgl1 = $this->input->post('tawal');
			$tgl2 = $this->input->post('takhir');
			$id = decrypt_url($this->input->post('vote'));
			$idp_fak = decrypt_url($this->input->post('fak'));
			$idp_jur = decrypt_url($this->input->post('jur'));

			if ($idp_fak != 0 and $lingkup == 'Fakultas')
			{
				$idp_jur = 0;
			}
			else if($idp_jur != 0 and $lingkup == 'Jurusan')
			{
				$idp_fak = 0;
			}
			else
			{
				$idp_jur = 0;
				$idp_fak = 0;
			}

			$data = array(
				'nama_vot' => $topik, 
				'lingkup_vot' => $lingkup, 
				'idp_jur' => $idp_jur, 
				'idp_fak' => $idp_fak, 
				'idp_grp' => $grp, 
				'tgl_awal' => $tgl1, 
				'tgl_akhir' => $tgl2, 
				'keterangan_vot' => $keterangan, 
			);

			$update = $this->db->update('tbl_mas_vote', $data,array('id_vot' => $id, ));
			$this->session->set_flashdata('notif', '<script>swal("Success","Vote berhasil disimpan","success");</script>');
			redirect('Admin/voting');
		}
	}

	function get_hasil()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST')
		{
			// $idvote = 6;
			$idvote = decrypt_url($this->input->post('arg'));
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$idvote.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$data['res'] =  $this->db->select('Nama AS label,RES_TOTAL AS value,Nama, NIM,bobot,Total_vote')->get_where('res_count_vote', 'id_vot = "'.$idvote.'"')->result();
				// end($data['res']);
				// $last_key = key($data['res']);;
				// adminPage('ajx/v_adm_vote',$data);
				$this->load->view('ajx/v_adm_vote', $data);
			}
			else
			{
				http_response_code(403);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function print_hasil_vote($arg = false)
	{
		if ($arg != false)
		{
			// $idvote = 6;
			$idvote = decrypt_url($arg);
			$cek = $this->db->get_where('tbv_vote','id_vot = "'.$idvote.'"');
			if ($cek->num_rows() > 0)
			{
				$data['vote'] = $cek->row();
				$data['title'] = 'Hasil Vote '.$data['vote']->nama_vot;
				$data['res'] =  $this->db->select('Nama AS label,RES_TOTAL AS value,Nama, NIM,bobot,Total_vote')->get_where('res_count_vote', 'id_vot = "'.$idvote.'"')->result();
				// end($data['res']);
				// $last_key = key($data['res']);;
				// adminPage('ajx/v_adm_vote',$data);
				$this->load->view('print_hasil', $data);
			}
			else
			{
				http_response_code(403);
			}
		}
		else
		{
			http_response_code(404);
		}
	}

	function hasil_vote()
	{
		$vote = $this->db->get_where('tbv_vote', 'id_vot = "8"')->row();
		$hasil = $this->db->get_where('res_count_vote', 'id_vot = "8"')->result();
		var_dump(round($hasil[0]->bobot,2));
	}
}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */