<?php

function dd($data){
	var_dump($data); 
	die;
}

function adminPage($view, $data = []){
	$CI = &get_instance();
	$data['content'] = $view;
	$CI->load->view('layouts/base_admin', $data);
}

function render($view, $data = []){
	$CI = &get_instance();
	$data['content'] = $view;
	$CI->load->view('layouts/base_mahasiswa', $data);
}

function render_fak($view, $data = []){
	$CI = &get_instance();
	$data['content'] = $view;
	$CI->load->view('layouts/base_fakultas', $data);
}

function limitText($text = false)
{
	if ($text != false)
	{
		$num_words = 6;
		$words = array();
		$words = explode(" ", $text, $num_words);
		$shown_string = "";
		if(count($words) == 6){
			$words[5] = " ... ";
		}
		$shown_string = implode(" ", $words);
		return $shown_string;
	}
	else
	{
		return false;
	}
}

function tgl_indo($tanggal){
	$bulan = array (
		1 =>   'Januari',
		'Februari',
		'Maret',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Agustus',
		'September',
		'Oktober',
		'November',
		'Desember'
	);
	$pecahkan = explode('-', $tanggal);
	
	// variabel pecahkan 0 = tanggal
	// variabel pecahkan 1 = bulan
	// variabel pecahkan 2 = tahun
 
	return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

function hari($tgl = false){
	$hari = date ("D",strtotime($tgl));
 
	if ($tgl != false)
	{
		switch($hari){
			case 'Sun':
				$hari_ini = "Minggu";
			break;
	 
			case 'Mon':			
				$hari_ini = "Senin";
			break;
	 
			case 'Tue':
				$hari_ini = "Selasa";
			break;
	 
			case 'Wed':
				$hari_ini = "Rabu";
			break;
	 
			case 'Thu':
				$hari_ini = "Kamis";
			break;
	 
			case 'Fri':
				$hari_ini = "Jumat";
			break;
	 
			case 'Sat':
				$hari_ini = "Sabtu";
			break;
			
			default:
				$hari_ini = "Tidak di ketahui";		
			break;
		}
	}
	else
	{
		$hari_ini = "Tidak di ketahui";
	}
 
	return $hari_ini;
 
}